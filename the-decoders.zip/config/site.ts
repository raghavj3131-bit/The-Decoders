/**
 * Single source of truth for global site values.
 * NOTE: stats below are placeholders — set them to your REAL numbers before launch.
 * Empty links render as "soon" (not as broken links).
 */
export const siteConfig = {
  name: "THE DECODERS",
  tagline: "DECODE YOUR FUTURE",
  description:
    "A community for people who don't just follow the future — they decode it. Programs, opportunities, events and people building real things.",

  stats: [
    { key: "students", label: "STUDENTS", value: 500, suffix: "+" },
    { key: "projects", label: "PROJECTS", value: 50, suffix: "+" },
    { key: "opportunities", label: "OPPORTUNITIES", value: 100, suffix: "+" },
    { key: "domains", label: "DOMAINS", value: 10, suffix: "+" },
  ],

  links: {
    whatsapp: "",
    instagram: "",
    youtube: "",
    linkedin: "",
  },
  contact: {
    email: "",
  },

  // Optional: set NEXT_PUBLIC_JOIN_ENDPOINT in .env.local to send the join form to a real backend.
  external: {
    joinEndpoint: process.env.NEXT_PUBLIC_JOIN_ENDPOINT ?? "",
  },

  nav: [
    { label: "HOME", href: "/" },
    { label: "ABOUT", href: "/about" },
    { label: "PROGRAMS", href: "/programs" },
    { label: "COMMUNITY", href: "/community" },
    { label: "OPPORTUNITIES", href: "/opportunities" },
    { label: "EVENTS", href: "/events" },
    { label: "RESOURCES", href: "/resources" },
    { label: "TEAM", href: "/team" },
    { label: "STORIES", href: "/stories" },
    { label: "JOIN", href: "/join" },
  ],
} as const;

export type NavItem = (typeof siteConfig.nav)[number];
