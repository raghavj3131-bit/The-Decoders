// Editable. Perks and groups describe intent; edit to match what you really offer.
export const identities = [
  { title: "THE BUILDER", text: "Turns ideas into working things, however rough the first version." },
  { title: "THE EXPLORER", text: "Tries every track, asks why, and connects ideas across fields." },
  { title: "THE CREATOR", text: "Makes videos, designs, writing and stories people want to see." },
  { title: "THE RESEARCHER", text: "Digs until the answer is real, then explains it simply." },
  { title: "THE LEADER", text: "Organizes people, runs sessions and lifts the group." },
  { title: "THE PROBLEM SOLVER", text: "Sees what is broken and fixes it with whatever tools fit." },
];

export const groups = [
  { title: "BUILD SQUADS", text: "Small teams that ship one project together." },
  { title: "STUDY CIRCLES", text: "Weekly groups that go deep on one topic." },
  { title: "OPPORTUNITY RADAR", text: "Members who track and share deadlines." },
  { title: "CREATOR LAB", text: "Feedback and collaboration for media and design." },
];

export const perks = [
  "Opportunities shared as they appear",
  "Feedback from people who build",
  "Roadmaps, notes and templates",
  "Events, sessions and challenges",
  "A network of peers and mentors",
];

export const rules = [
  { n: "01", t: "BUILD WITH CURIOSITY" },
  { n: "02", t: "SHARE WHAT YOU LEARN" },
  { n: "03", t: "RESPECT THE COMMUNITY" },
  { n: "04", t: "MAKE SOMETHING REAL" },
];
