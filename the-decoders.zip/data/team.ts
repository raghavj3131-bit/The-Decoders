// PLACEHOLDERS — replace with real people. Nothing here is a real credential or achievement.
export type Person = {
  id: string;
  name: string;
  role: string;
  bio: string;
  photo: string | null; // path under /public, e.g. "/team/name.jpg"
  socials: { instagram?: string; linkedin?: string; youtube?: string; x?: string };
};

export const coreTeam: Person[] = [
  { id: "c1", name: "Founder Name", role: "Founder", bio: "Add a short bio here.", photo: null, socials: {} },
  { id: "c2", name: "Team Member", role: "Community Lead", bio: "Add a short bio here.", photo: null, socials: {} },
  { id: "c3", name: "Team Member", role: "Programs Lead", bio: "Add a short bio here.", photo: null, socials: {} },
];

export const mentors: Person[] = [
  { id: "m1", name: "Mentor Name", role: "Mentor", bio: "Mentors will be announced soon.", photo: null, socials: {} },
  { id: "m2", name: "Mentor Name", role: "Mentor", bio: "Mentors will be announced soon.", photo: null, socials: {} },
];
