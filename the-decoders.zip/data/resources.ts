// SAMPLE DATA — add real links via `href`. Items without href point people to /join.
export const resourceTabs = ["ROADMAPS", "NOTES", "TOOLS"] as const;
export type ResourceTab = (typeof resourceTabs)[number];

export type Resource = {
  id: string;
  title: string;
  tab: ResourceTab;
  category: string;
  difficulty: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  description: string;
  href?: string;
};

export const resources: Resource[] = [
  { id: "r1", title: "Zero to First Project: Coding", tab: "ROADMAPS", category: "CODING", difficulty: "BEGINNER", description: "A step-by-step path from your first line of code to a shipped project." },
  { id: "r2", title: "AI Engineer Path", tab: "ROADMAPS", category: "AI", difficulty: "INTERMEDIATE", description: "The order to learn math, Python, ML and deployment, without the detours." },
  { id: "r3", title: "Design Foundations", tab: "ROADMAPS", category: "DESIGN", difficulty: "BEGINNER", description: "Typography, layout and interface basics in a sensible sequence." },
  { id: "r4", title: "Security Starter Notes", tab: "NOTES", category: "CYBERSECURITY", difficulty: "BEGINNER", description: "Plain-language notes on networks, web basics and safe practice." },
  { id: "r5", title: "Research Reading Guide", tab: "NOTES", category: "RESEARCH", difficulty: "INTERMEDIATE", description: "How to read a paper in 30 minutes and decide if it is worth more." },
  { id: "r6", title: "Pitch Structure Cheatsheet", tab: "NOTES", category: "ENTREPRENEURSHIP", difficulty: "BEGINNER", description: "The six slides every early pitch needs, and what to cut." },
  { id: "r7", title: "Builder's Toolkit", tab: "TOOLS", category: "GENERAL", difficulty: "BEGINNER", description: "A curated set of free tools for coding, design and productivity." },
  { id: "r8", title: "Hackathon Checklist", tab: "TOOLS", category: "HACKATHONS", difficulty: "INTERMEDIATE", description: "Team roles, time boxes and demo prep for your next hackathon." },
  { id: "r9", title: "Portfolio Template Pack", tab: "TOOLS", category: "CAREER", difficulty: "BEGINNER", description: "Starter layouts for a clean developer or designer portfolio." },
];
