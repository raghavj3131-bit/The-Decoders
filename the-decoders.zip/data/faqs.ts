export const faqs = [
  { q: "Who is The Decoders for?", a: "Students and young builders who are curious about technology and want to turn that curiosity into projects, skills and opportunities." },
  { q: "Do I need experience?", a: "No. There are tracks for complete beginners and for people who already build. Start where you are." },
  { q: "What happens after I request access?", a: "You will be invited to the community space where programs, opportunities and events are shared." },
  { q: "How can I contribute?", a: "Share what you learn, help another member, or run a session. Contributors shape what the community becomes." },
];
