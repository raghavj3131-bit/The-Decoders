export type Program = {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  what: string;
  learn: string[];
  projects: string[];
  skills: string[];
  opportunities: string[];
};

export const programs: Program[] = [
  {
    id: "ai", number: "01", title: "AI", tagline: "Teach machines. Understand minds.",
    description: "From first model to real product. Learn how modern AI actually works, then build with it.",
    what: "A hands-on track on machine learning and applied AI, from fundamentals to shipping a working tool.",
    learn: ["Python for data and ML", "How models learn and fail", "Working with LLM APIs", "Evaluating and deploying a model"],
    projects: ["A classifier trained on your own dataset", "A study assistant built on an LLM API", "A small vision project"],
    skills: ["Python", "Data handling", "Prompting", "Model evaluation"],
    opportunities: ["Hackathons", "Research assistant roles", "Internships"],
  },
  {
    id: "robotics", number: "02", title: "ROBOTICS", tagline: "Code that moves in the real world.",
    description: "Sensors, motors and logic. Build machines that sense, decide and act.",
    what: "A maker track for electronics, embedded code and mechanical thinking.",
    learn: ["Microcontroller basics", "Sensors and actuators", "Control logic", "Debugging hardware"],
    projects: ["Line-following robot", "Obstacle-avoiding vehicle", "A sensor-driven home automation prototype"],
    skills: ["Embedded C/C++", "Circuits", "CAD basics", "Problem decomposition"],
    opportunities: ["Robotics competitions", "Maker workshops", "Internships"],
  },
  {
    id: "coding", number: "03", title: "CODING", tagline: "Write the thing you wish existed.",
    description: "Learn to build software properly: web, apps and the fundamentals behind them.",
    what: "A software track focused on shipping projects, not collecting certificates.",
    learn: ["Programming fundamentals", "Web development", "Git and collaboration", "Data structures in practice"],
    projects: ["A personal portfolio site", "A full-stack utility app", "An open-source contribution"],
    skills: ["JavaScript / TypeScript", "Python", "Git", "APIs"],
    opportunities: ["Hackathons", "Internships", "Open-source programs"],
  },
  {
    id: "design", number: "04", title: "DESIGN", tagline: "Make it clear. Make it unforgettable.",
    description: "Visual design, interface design and brand thinking, learned by making real things.",
    what: "A creative track on UI/UX, visual identity and motion.",
    learn: ["Layout and typography", "Interface design", "Design systems", "Presenting your work"],
    projects: ["A redesign of an app you use", "A brand identity for a fictional startup", "A motion piece"],
    skills: ["Figma", "Typography", "Prototyping", "Visual storytelling"],
    opportunities: ["Design challenges", "Freelance projects", "Internships"],
  },
  {
    id: "entrepreneurship", number: "05", title: "ENTREPRENEURSHIP", tagline: "Spot the problem. Build the answer.",
    description: "Validate ideas, build a first version and learn how businesses actually start.",
    what: "A builder track on ideas, customers, money and execution.",
    learn: ["Finding real problems", "Customer interviews", "Building a minimum product", "Pitching clearly"],
    projects: ["A validated idea with real user feedback", "A one-page business model", "A live pitch"],
    skills: ["Research", "Pitching", "Basic finance", "Execution"],
    opportunities: ["Startup competitions", "Mentorship", "Incubator applications"],
  },
  {
    id: "cybersecurity", number: "06", title: "CYBERSECURITY", tagline: "Think like an attacker. Build like a defender.",
    description: "Understand how systems break so you can protect them. Ethical, legal and practical.",
    what: "A security track built around safe labs and capture-the-flag practice.",
    learn: ["Networking fundamentals", "Common web vulnerabilities", "Secure habits", "Capture-the-flag basics"],
    projects: ["Complete beginner CTF challenges", "Audit a practice app in a safe lab", "A personal security checklist"],
    skills: ["Linux", "Networking", "Web security basics", "Analytical thinking"],
    opportunities: ["CTF competitions", "Workshops", "Internships"],
  },
  {
    id: "media", number: "07", title: "MEDIA", tagline: "Tell stories people remember.",
    description: "Video, writing and audience building. Learn to make things people actually watch.",
    what: "A creator track on storytelling, editing and distribution.",
    learn: ["Scripting and structure", "Editing and sound", "Thumbnails and titles", "Reading analytics"],
    projects: ["A short documentary", "A weekly content series", "A channel or page launch plan"],
    skills: ["Editing", "Writing", "Storytelling", "Analytics"],
    opportunities: ["Creator collaborations", "Content internships", "Competitions"],
  },
  {
    id: "research", number: "08", title: "RESEARCH", tagline: "Ask better questions.",
    description: "Learn how real research works: reading papers, designing experiments, writing it up.",
    what: "A thinking track on method, evidence and communication.",
    learn: ["Reading papers", "Framing a question", "Experiment design", "Writing and presenting findings"],
    projects: ["A literature review", "A small original study", "A poster or short paper"],
    skills: ["Critical reading", "Statistics basics", "Academic writing", "Presenting"],
    opportunities: ["Research mentorship", "Student conferences", "Fellowships"],
  },
];
