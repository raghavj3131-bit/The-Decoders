// SAMPLE DATA — replace with your real events. Status is explicit (no date maths at render time).
export type EventItem = {
  id: string;
  date: string; // ISO yyyy-mm-dd
  title: string;
  category: string;
  location: string;
  description: string;
  status: "upcoming" | "past";
};

export const events: EventItem[] = [
  { id: "e1", date: "2026-11-22", title: "Decoders Build Day", category: "WORKSHOP", location: "Online", description: "A full day to start and ship a small project with other members. Sample event.", status: "upcoming" },
  { id: "e2", date: "2026-12-13", title: "Open Mic: Ideas Worth Building", category: "MEETUP", location: "Online", description: "Short pitches, quick feedback, new collaborators. Sample event.", status: "upcoming" },
  { id: "e3", date: "2027-01-17", title: "Decoders Mini Hackathon", category: "HACKATHON", location: "To be announced", description: "A weekend sprint around one theme. Sample event.", status: "upcoming" },
  { id: "e4", date: "2026-09-06", title: "Intro to Decoding Session", category: "SESSION", location: "Online", description: "How the community works and how to get the most from it. Sample event.", status: "past" },
  { id: "e5", date: "2026-08-02", title: "Resume and Portfolio Clinic", category: "WORKSHOP", location: "Online", description: "Live reviews of member resumes and portfolios. Sample event.", status: "past" },
  { id: "e6", date: "2026-06-14", title: "Founding Members Call", category: "MEETUP", location: "Online", description: "The first community-wide conversation. Sample event.", status: "past" },
];
