// PLACEHOLDERS — do not publish until replaced with real, consented student stories.
export type Story = {
  id: string;
  name: string;
  achievement: string;
  year: string;
  category: string;
  quote: string;
  image: string | null;
  tall: boolean;
};

export const stories: Story[] = [
  { id: "s1", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "CODING", quote: "A real quote from a real member will live here.", image: null, tall: true },
  { id: "s2", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "DESIGN", quote: "A real quote from a real member will live here.", image: null, tall: false },
  { id: "s3", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "AI", quote: "A real quote from a real member will live here.", image: null, tall: false },
  { id: "s4", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "RESEARCH", quote: "A real quote from a real member will live here.", image: null, tall: true },
  { id: "s5", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "MEDIA", quote: "A real quote from a real member will live here.", image: null, tall: false },
  { id: "s6", name: "Student Name", achievement: "Your story goes here", year: "2026", category: "ENTREPRENEURSHIP", quote: "A real quote from a real member will live here.", image: null, tall: true },
];
