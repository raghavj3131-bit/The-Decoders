// SAMPLE DATA — replace with real listings. Organizations below are fictional placeholders.
export const opportunityCategories = ["ALL", "HACKATHONS", "INTERNSHIPS", "COMPETITIONS", "MENTORSHIP", "RESEARCH", "WORKSHOPS"] as const;
export type OpportunityCategory = Exclude<(typeof opportunityCategories)[number], "ALL">;

export type Opportunity = {
  id: string;
  title: string;
  category: OpportunityCategory;
  organization: string;
  location: string;
  deadline: string; // ISO
  description: string;
};

export const opportunities: Opportunity[] = [
  { id: "o1", title: "48-Hour Build Sprint", category: "HACKATHONS", organization: "Sample Org A", location: "Online", deadline: "2026-11-15", description: "Team up and build a working prototype around a single theme." },
  { id: "o2", title: "Campus Hack Series", category: "HACKATHONS", organization: "Sample Org B", location: "Hybrid", deadline: "2026-12-05", description: "Multi-round student hackathon with mentor office hours." },
  { id: "o3", title: "Junior Developer Intern", category: "INTERNSHIPS", organization: "Sample Org C", location: "Remote", deadline: "2026-11-30", description: "Work on a real product with a small engineering team." },
  { id: "o4", title: "Design Intern, Product", category: "INTERNSHIPS", organization: "Sample Org D", location: "Remote", deadline: "2026-12-12", description: "Support interface design for a growing consumer app." },
  { id: "o5", title: "National Student Coding Contest", category: "COMPETITIONS", organization: "Sample Org E", location: "Online", deadline: "2026-11-20", description: "Algorithmic problem solving across three rounds." },
  { id: "o6", title: "Young Founders Pitch Challenge", category: "COMPETITIONS", organization: "Sample Org F", location: "Online", deadline: "2027-01-10", description: "Pitch your idea to a panel and win seed support." },
  { id: "o7", title: "Industry Mentor Match", category: "MENTORSHIP", organization: "Sample Org G", location: "Online", deadline: "2026-12-01", description: "Matched with a working professional for a 3-month mentorship." },
  { id: "o8", title: "Peer Mentor Circle", category: "MENTORSHIP", organization: "The Decoders", location: "Online", deadline: "2026-11-25", description: "Small groups led by senior members, focused on one skill." },
  { id: "o9", title: "Undergraduate Research Assistant", category: "RESEARCH", organization: "Sample Org H", location: "Remote", deadline: "2026-12-20", description: "Assist on a literature-driven study in applied computing." },
  { id: "o10", title: "Student Research Showcase", category: "RESEARCH", organization: "Sample Org I", location: "Hybrid", deadline: "2027-01-05", description: "Submit a poster or short paper to a student conference." },
  { id: "o11", title: "Practical AI Workshop", category: "WORKSHOPS", organization: "Sample Org J", location: "Online", deadline: "2026-11-18", description: "A two-day hands-on workshop building with LLM APIs." },
  { id: "o12", title: "Intro to Capture-the-Flag", category: "WORKSHOPS", organization: "The Decoders", location: "Online", deadline: "2026-12-08", description: "Learn the basics and solve your first challenges live." },
];
