// Editable story copy. Keep it true: replace with your real timeline.
export const timeline = [
  { n: "01", title: "THE BEGINNING", text: "A small group of students who kept finding opportunities and kept sharing them." },
  { n: "02", title: "THE IDEA", text: "Opportunity should not depend on who you know. Make it easy to find and easy to act on." },
  { n: "03", title: "THE FIRST BUILDERS", text: "The first members started asking questions, joining challenges and building their own things." },
  { n: "04", title: "THE COMMUNITY", text: "A space where students help students: shared notes, shared deadlines, shared wins." },
  { n: "05", title: "THE MOVEMENT", text: "Curiosity turning into action, one project at a time." },
  { n: "06", title: "WHAT COMES NEXT", text: "Programs, events and partnerships that give every member a real shot at something real." },
];

export const mission = "Build a community where curiosity becomes action.";
export const vision = "A generation capable of decoding and building the future.";
export const values = ["CURIOSITY", "BUILD", "SHARE", "EXPERIMENT", "IMPACT"];
