"use client";
import { useEffect } from "react";
import { scrollState } from "@/lib/scrollState";

/** Re-mounts on every navigation: reset scroll (under the closed shutter) and refresh ScrollTrigger. */
export default function Template({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const l = scrollState.lenis;
    if (l) l.scrollTo(0, { immediate: true, force: true });
    else window.scrollTo(0, 0);
    const t = setTimeout(async () => {
      const { ScrollTrigger } = await import("gsap/ScrollTrigger");
      ScrollTrigger.refresh();
    }, 150);
    return () => clearTimeout(t);
  }, []);
  return <>{children}</>;
}
