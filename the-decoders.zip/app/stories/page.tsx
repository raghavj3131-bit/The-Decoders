import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import StoriesMasonry from "@/components/sections/StoriesMasonry";

export const metadata: Metadata = { title: "Stories" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 09 // STORIES" lines={["THEY", "STARTED", "SOMEWHERE."]} variant="stories" />
      <StoriesMasonry />
    </>
  );
}
