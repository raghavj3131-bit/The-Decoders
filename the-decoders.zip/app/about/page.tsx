import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import AboutTimeline from "@/components/sections/AboutTimeline";

export const metadata: Metadata = { title: "About" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 02 // ABOUT" lines={["THIS IS", "WHERE WE", "STARTED."]} variant="about" />
      <AboutTimeline />
    </>
  );
}
