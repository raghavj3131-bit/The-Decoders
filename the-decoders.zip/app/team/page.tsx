import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import TeamGrid from "@/components/sections/TeamGrid";

export const metadata: Metadata = { title: "Team" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 08 // TEAM" lines={["THE PEOPLE", "BEHIND", "THE DECODING."]} variant="team" align="center" />
      <TeamGrid />
    </>
  );
}
