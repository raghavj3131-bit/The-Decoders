import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import JoinContent from "@/components/sections/JoinContent";

export const metadata: Metadata = { title: "Join" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 10 // ACCESS" lines={["READY", "TO", "DECODE?"]} variant="join" align="center" />
      <JoinContent />
    </>
  );
}
