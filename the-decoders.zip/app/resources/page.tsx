import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import ResourcesTabs from "@/components/sections/ResourcesTabs";

export const metadata: Metadata = { title: "Resources" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 07 // RESOURCES" lines={["KNOWLEDGE", "IS", "LEVERAGE."]} variant="resources" skew />
      <ResourcesTabs />
    </>
  );
}
