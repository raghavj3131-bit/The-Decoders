import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import CommunityBlocks from "@/components/sections/CommunityBlocks";

export const metadata: Metadata = { title: "Community" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 04 // COMMUNITY" lines={["YOU DON'T", "BUILD", "ALONE."]} variant="community" align="center" />
      <CommunityBlocks />
    </>
  );
}
