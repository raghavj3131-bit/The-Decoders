import type { Metadata, Viewport } from "next";
import { Anton, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { siteConfig } from "@/config/site";
import SmoothScrollProvider from "@/components/providers/SmoothScrollProvider";
import ShutterTransitionProvider from "@/components/providers/ShutterTransitionProvider";
import Loader from "@/components/animations/Loader";
import ClickSplash from "@/components/animations/ClickSplash";
import ImpactFlash from "@/components/animations/ImpactFlash";
import SpeedLines from "@/components/animations/SpeedLines";
import FilmGrain from "@/components/effects/FilmGrain";
import CursorGlow from "@/components/effects/CursorGlow";
import Navbar from "@/components/navigation/Navbar";
import Footer from "@/components/layout/Footer";

const display = Anton({ subsets: ["latin"], weight: "400", variable: "--font-display", display: "swap" });
const body = Space_Grotesk({ subsets: ["latin"], variable: "--font-body", display: "swap" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono", display: "swap" });

export const metadata: Metadata = {
  title: { default: `${siteConfig.name} — ${siteConfig.tagline}`, template: `%s — ${siteConfig.name}` },
  description: siteConfig.description,
  icons: { icon: "/logo.svg" },
  openGraph: { title: siteConfig.name, description: siteConfig.description, type: "website" },
};

export const viewport: Viewport = { themeColor: "#050507", width: "device-width", initialScale: 1 };

const loaderScript = `try{if(!sessionStorage.getItem("decoders-loader-seen")&&!matchMedia("(prefers-reduced-motion: reduce)").matches)document.documentElement.classList.add("show-loader")}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: loaderScript }} />
        <noscript>
          <style>{`.tr-unit,.hero-w,.hero-fade{opacity:1!important;transform:none!important;filter:none!important}.rv-wipe{clip-path:none!important}.loader{display:none!important}`}</style>
        </noscript>
      </head>
      <body className="bg-void font-sans text-ink antialiased">
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <SmoothScrollProvider>
          <ShutterTransitionProvider>
            <Loader />
            <FilmGrain />
            <CursorGlow />
            <ClickSplash />
            <ImpactFlash />
            <SpeedLines mode="scroll" />
            <Navbar />
            <main id="main">{children}</main>
            <Footer />
          </ShutterTransitionProvider>
        </SmoothScrollProvider>
      </body>
    </html>
  );
}
