import Hero from "@/components/home/Hero";
import AboutSection from "@/components/home/AboutSection";
import Numbers from "@/components/home/Numbers";
import ProgramsPinned from "@/components/home/ProgramsPinned";
import EventsArchive from "@/components/home/EventsArchive";
import CommunitySection from "@/components/home/CommunitySection";
import FinalCTA from "@/components/home/FinalCTA";
import Marquee from "@/components/ui/Marquee";
import { marqueeItems } from "@/data/home";

export default function HomePage() {
  return (
    <>
      <Hero />
      <AboutSection />
      <Numbers />
      <ProgramsPinned />
      <div className="border-y border-white/10 py-10" aria-label="What you will find inside">
        <Marquee items={marqueeItems} />
      </div>
      <EventsArchive />
      <CommunitySection />
      <FinalCTA />
    </>
  );
}
