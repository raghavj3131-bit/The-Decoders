import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import EventsTabs from "@/components/sections/EventsTabs";

export const metadata: Metadata = { title: "Events" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 06 // EVENTS" lines={["THE", "MOMENTS", "THAT MATTER."]} variant="events" align="right" />
      <EventsTabs />
    </>
  );
}
