import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import ProgramChapters from "@/components/sections/ProgramChapters";

export const metadata: Metadata = { title: "Programs" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 03 // PROGRAMS" lines={["CHOOSE", "WHAT YOU", "WANT TO", "DECODE."]} variant="programs" align="right" />
      <ProgramChapters />
    </>
  );
}
