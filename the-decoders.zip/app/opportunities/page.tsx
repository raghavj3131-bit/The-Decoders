import type { Metadata } from "next";
import PageHero from "@/components/layout/PageHero";
import OpportunitiesGrid from "@/components/sections/OpportunitiesGrid";

export const metadata: Metadata = { title: "Opportunities" };

export default function Page() {
  return (
    <>
      <PageHero system="SYSTEM 05 // OPPORTUNITIES" lines={["FIND YOUR", "NEXT", "OPPORTUNITY."]} variant="opportunities" />
      <OpportunitiesGrid />
    </>
  );
}
