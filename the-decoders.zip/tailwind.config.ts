import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#050507",
        night: "#08060D",
        abyss: "#0D0915",
        volt: { DEFAULT: "#8B5CF6", deep: "#7C3AED", hot: "#A855F7" },
        ink: "#F5F5F5",
        ash: "#8A8A95",
        signal: "#E5243B",
      },
      fontFamily: {
        display: ["var(--font-display)", "Impact", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
    },
  },
  plugins: [],
};
export default config;
