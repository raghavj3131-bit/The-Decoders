# THE DECODERS — cinematic site

Next.js 14 (App Router) · TypeScript · Tailwind · Framer Motion · GSAP + ScrollTrigger · anime.js · Lenis · React Three Fiber

## Run
```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## Before launch (important)
1. **Replace `public/logo.svg`** with your real logo. The one in the zip is a placeholder. The loader inlines whatever SVG is there and stroke-draws every shape, then fades the original fill in (works for fill-only logos).
2. **`config/site.ts`**: set REAL stats, social links, WhatsApp, email. Empty links show as "soon", not broken links.
3. **`data/*.ts`**: events, opportunities, resources, team, stories are SAMPLE/PLACEHOLDER content. Replace before publishing.
4. **Join form** is in DEMO mode (UI says "DEMO SUBMISSION", nothing is stored). To go live set `NEXT_PUBLIC_JOIN_ENDPOINT` in `.env.local` to an endpoint that accepts a JSON POST, or edit `lib/submitAccessRequest.ts`.

## Where things live
- Loader: `components/animations/Loader.tsx` (once per session, key `decoders-loader-seen`, ~2.5s)
- Shutter: `components/animations/ShutterTransition.tsx` + `components/providers/ShutterTransitionProvider.tsx` (`/join` uses horizontal blinds)
- Every internal link must use `TransitionLink` / `MagneticButton` so it gets the shutter
- Smooth scroll + ScrollTrigger sync: `components/providers/SmoothScrollProvider.tsx`
- Pinned horizontal programs: `components/home/ProgramsPinned.tsx`
