"use client";
import { useEffect } from "react";
import { scrollState } from "@/lib/scrollState";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

export default function SmoothScrollProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    let cancelled = false;
    let cleanup: (() => void) | undefined;

    (async () => {
      const [{ default: Lenis }, { gsap }, { ScrollTrigger }] = await Promise.all([
        import("lenis"),
        import("gsap"),
        import("gsap/ScrollTrigger"),
      ]);
      if (cancelled) return;
      gsap.registerPlugin(ScrollTrigger);

      // Reduced motion: native scroll, but ScrollTrigger still works.
      if (prefersReducedMotion()) {
        const onScroll = () => ScrollTrigger.update();
        window.addEventListener("scroll", onScroll, { passive: true });
        cleanup = () => window.removeEventListener("scroll", onScroll);
        return;
      }

      const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 1, smoothWheel: true });
      scrollState.lenis = lenis;

      lenis.on("scroll", (e: { velocity: number }) => {
        ScrollTrigger.update();
        scrollState.emit(e.velocity);
      });

      const tick = (time: number) => lenis.raf(time * 1000);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);

      cleanup = () => {
        gsap.ticker.remove(tick);
        lenis.destroy();
        scrollState.lenis = null;
        scrollState.emit(0);
      };
    })();

    return () => {
      cancelled = true;
      cleanup?.();
    };
  }, []);

  return <>{children}</>;
}
