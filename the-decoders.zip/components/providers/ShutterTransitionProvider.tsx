"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import ShutterTransition, { type ShutterHandle } from "@/components/animations/ShutterTransition";
import { motionState } from "@/lib/motionState";
import { scrollState } from "@/lib/scrollState";
import { fx } from "@/lib/fx";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

export type NavOptions = { cta?: boolean; x?: number; y?: number; onStart?: () => void };
type Ctx = { navigate: (href: string, opts?: NavOptions) => void };

export const ShutterTransitionContext = createContext<Ctx | null>(null);

export function useShutter() {
  const c = useContext(ShutterTransitionContext);
  if (!c) throw new Error("useShutter must be used inside ShutterTransitionProvider");
  return c;
}

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export default function ShutterTransitionProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const shutter = useRef<ShutterHandle>(null);
  const busy = useRef(false);
  const pending = useRef<{ path: string; resolve: () => void } | null>(null);
  const pathRef = useRef(pathname);
  pathRef.current = pathname;

  useEffect(() => {
    if (pending.current && pending.current.path === pathname) {
      pending.current.resolve();
      pending.current = null;
    }
  }, [pathname]);

  const navigate = useCallback(
    async (href: string, opts: NavOptions = {}) => {
      if (busy.current) return;
      const path = href.split("#")[0].split("?")[0] || "/";
      if (path === pathRef.current) {
        const l = scrollState.lenis;
        if (l) l.scrollTo(0);
        else window.scrollTo({ top: 0 });
        return;
      }
      busy.current = true;
      opts.onStart?.();
      const reduced = prefersReducedMotion();
      motionState.setReady(false);
      try {
        if (opts.cta && !reduced) {
          const x = opts.x ?? window.innerWidth / 2;
          const y = opts.y ?? window.innerHeight / 2;
          fx.splash(x, y, "cta");
          fx.flash();
          fx.shake();
          await wait(240);
        }
        if (!reduced) await shutter.current?.close(path === "/join" ? "blinds" : "shutter");

        const changed = new Promise<void>((resolve) => {
          pending.current = { path, resolve };
          setTimeout(resolve, 3000); // safety net
        });
        router.push(href);
        await changed;
        await wait(80); // let the new page mount under the shutter

        motionState.setReady(true);
        if (!reduced) await shutter.current?.open();
      } finally {
        busy.current = false;
        motionState.setReady(true);
      }
    },
    [router]
  );

  const value = useMemo(() => ({ navigate }), [navigate]);

  return (
    <ShutterTransitionContext.Provider value={value}>
      {children}
      <ShutterTransition ref={shutter} />
    </ShutterTransitionContext.Provider>
  );
}
