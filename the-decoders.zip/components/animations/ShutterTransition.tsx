"use client";
import { forwardRef, useImperativeHandle, useRef } from "react";

export type ShutterMode = "shutter" | "blinds";
export type ShutterHandle = {
  close: (mode: ShutterMode) => Promise<void>;
  open: () => Promise<void>;
};

const N = 7;
const DUR = 520;
const STAGGER = 50;
const EASE = "cubic-bezier(0.76, 0, 0.24, 1)";
const idx = Array.from({ length: N }, (_, i) => i);

const ShutterTransition = forwardRef<ShutterHandle>(function ShutterTransition(_, ref) {
  const root = useRef<HTMLDivElement>(null);
  const vRefs = useRef<(HTMLDivElement | null)[]>([]);
  const hRefs = useRef<(HTMLDivElement | null)[]>([]);
  const mode = useRef<ShutterMode>("shutter");

  const panels = (m: ShutterMode) =>
    ((m === "blinds" ? hRefs : vRefs).current.filter(Boolean) as HTMLDivElement[]);

  useImperativeHandle(ref, () => ({
    async close(m) {
      mode.current = m;
      const el = root.current;
      if (!el) return;
      el.style.pointerEvents = "auto";
      const blinds = m === "blinds";
      const anims = panels(m).map((p, i) => {
        p.getAnimations().forEach((a) => a.cancel());
        p.style.transformOrigin = blinds ? "left center" : "center bottom";
        return p.animate(
          [{ transform: blinds ? "scaleX(0)" : "scaleY(0)" }, { transform: blinds ? "scaleX(1)" : "scaleY(1)" }],
          { duration: DUR, delay: i * STAGGER, easing: EASE, fill: "forwards" }
        );
      });
      await Promise.all(anims.map((a) => a.finished));
    },
    async open() {
      const el = root.current;
      if (!el) return;
      const m = mode.current;
      const blinds = m === "blinds";
      const anims = panels(m).map((p, i) => {
        p.getAnimations().forEach((a) => a.cancel());
        p.style.transformOrigin = blinds ? "right center" : "center top";
        return p.animate(
          [{ transform: blinds ? "scaleX(1)" : "scaleY(1)" }, { transform: blinds ? "scaleX(0)" : "scaleY(0)" }],
          { duration: DUR, delay: i * STAGGER, easing: EASE, fill: "forwards" }
        );
      });
      await Promise.all(anims.map((a) => a.finished));
      el.style.pointerEvents = "none";
    },
  }));

  return (
    <div ref={root} aria-hidden="true" className="pointer-events-none fixed inset-0 z-[9000] overflow-hidden">
      {/* vertical panels (default) */}
      <div className="absolute inset-0 flex">
        {idx.map((i) => (
          <div
            key={`v${i}`}
            ref={(el) => {
              vRefs.current[i] = el;
            }}
            className="shutter-v h-full"
            style={{ width: "calc(100% / 7 + 1px)", marginRight: -1, flexShrink: 0, transform: "scaleY(0)" }}
          />
        ))}
      </div>
      {/* horizontal blinds (used for /join) */}
      <div className="absolute inset-0 flex flex-col">
        {idx.map((i) => (
          <div
            key={`h${i}`}
            ref={(el) => {
              hRefs.current[i] = el;
            }}
            className="shutter-h w-full"
            style={{ height: "calc(100% / 7 + 1px)", marginBottom: -1, flexShrink: 0, transform: "scaleX(0)" }}
          />
        ))}
      </div>
    </div>
  );
});

export default ShutterTransition;
