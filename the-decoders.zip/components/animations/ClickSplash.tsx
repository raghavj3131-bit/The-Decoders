"use client";
import { useEffect, useRef } from "react";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

export default function ClickSplash() {
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = box.current;
    if (!host) return;

    const ring = (x: number, y: number) => {
      const el = document.createElement("div");
      el.className = "splash-ring";
      el.style.left = `${x}px`;
      el.style.top = `${y}px`;
      host.appendChild(el);
      el
        .animate(
          [
            { transform: "translate(-50%,-50%) scale(0.1)", opacity: 0.9 },
            { transform: "translate(-50%,-50%) scale(1)", opacity: 0 },
          ],
          { duration: 550, easing: "cubic-bezier(.16,1,.3,1)" }
        )
        .finished.then(() => el.remove(), () => el.remove());
    };

    const big = (x: number, y: number) => {
      const r = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y)) * 1.4;
      const el = document.createElement("div");
      el.className = "splash-fill";
      el.style.left = `${x - r}px`;
      el.style.top = `${y - r}px`;
      el.style.width = el.style.height = `${r * 2}px`;
      host.appendChild(el);
      el
        .animate(
          [
            { transform: "scale(0)", opacity: 1 },
            { transform: "scale(1)", opacity: 1, offset: 0.7 },
            { transform: "scale(1)", opacity: 0 },
          ],
          { duration: 700, easing: "cubic-bezier(.16,1,.3,1)" }
        )
        .finished.then(() => el.remove(), () => el.remove());
    };

    const onSplash = (e: Event) => {
      if (prefersReducedMotion()) return;
      const { x, y, kind } = (e as CustomEvent<{ x: number; y: number; kind: "normal" | "cta" }>).detail;
      if (kind === "cta") big(x, y);
      else ring(x, y);
    };

    const onShake = () => {
      if (prefersReducedMotion()) return;
      const main = document.getElementById("main");
      main?.animate(
        [
          { left: "0px", top: "0px" },
          { left: "-3px", top: "2px" },
          { left: "3px", top: "-2px" },
          { left: "-2px", top: "-2px" },
          { left: "0px", top: "0px" },
        ],
        { duration: 150 }
      );
    };

    const onDown = (e: PointerEvent) => {
      if (prefersReducedMotion()) return;
      if ((e.target as Element | null)?.closest?.("[data-cta]")) return; // CTA has its own splash
      ring(e.clientX, e.clientY);
    };

    window.addEventListener("decoders:splash", onSplash);
    window.addEventListener("decoders:shake", onShake);
    window.addEventListener("pointerdown", onDown, { passive: true });
    return () => {
      window.removeEventListener("decoders:splash", onSplash);
      window.removeEventListener("decoders:shake", onShake);
      window.removeEventListener("pointerdown", onDown);
    };
  }, []);

  return <div ref={box} aria-hidden="true" className="pointer-events-none fixed inset-0 z-[8500] overflow-hidden" />;
}
