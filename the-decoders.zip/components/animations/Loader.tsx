"use client";
import { useEffect, useRef, useState } from "react";
import DecodeText from "./DecodeText";
import { motionState } from "@/lib/motionState";
import { fx } from "@/lib/fx";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

const KEY = "decoders-loader-seen";
const N = 7;

export default function Loader() {
  const contentRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const logoWrapRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const countRef = useRef<HTMLSpanElement>(null);
  const statusRef = useRef<HTMLSpanElement>(null);
  const panelRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [decode, setDecode] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem(KEY) === "1";
    } catch {}

    const finish = () => {
      try {
        sessionStorage.setItem(KEY, "1");
      } catch {}
      document.documentElement.classList.remove("show-loader");
      motionState.setReady(true);
      setGone(true);
    };

    if (seen || prefersReducedMotion()) {
      finish();
      return;
    }

    let cancelled = false;
    let tl: { kill: () => void } | undefined;

    (async () => {
      const { gsap } = await import("gsap");
      if (cancelled) return;

      // ---- inline the REAL logo.svg and prepare it for stroke-drawing ----
      let paths: SVGGeometryElement[] = [];
      try {
        const res = await fetch("/logo.svg");
        const txt = await res.text();
        if (cancelled) return;
        const doc = new DOMParser().parseFromString(txt, "image/svg+xml");
        const svg = doc.documentElement;
        svg.removeAttribute("width");
        svg.removeAttribute("height");
        svg.setAttribute("class", "h-full w-full overflow-visible");
        const host = logoRef.current;
        if (host) {
          host.innerHTML = "";
          const node = document.importNode(svg, true) as unknown as SVGSVGElement;
          host.appendChild(node);
          const vb = node.viewBox?.baseVal;
          const strokeW = vb && vb.width ? Math.max(vb.width, vb.height) / 90 : 2;
          paths = Array.from(
            node.querySelectorAll<SVGGeometryElement>("path,circle,rect,polygon,polyline,line,ellipse")
          ).filter((el) => !el.closest("defs,clipPath,mask,symbol"));
          paths = paths.filter((el) => {
            let len = 0;
            try {
              len = el.getTotalLength();
            } catch {}
            if (!len) return false;
            el.style.setProperty("stroke-dasharray", `${len}`);
            el.style.setProperty("stroke-dashoffset", `${len}`);
            el.style.setProperty("stroke", "#A855F7");
            el.style.setProperty("stroke-width", `${strokeW}`);
            el.style.setProperty("stroke-linejoin", "round");
            el.style.setProperty("fill-opacity", "0"); // fill-only logos: fade the original fill in after the draw
            return true;
          });
        }
      } catch {}
      if (cancelled) return;

      const panels = panelRefs.current.filter(Boolean) as HTMLDivElement[];
      const counter = { v: 0 };
      const t = gsap.timeline({ defaults: { ease: "power2.out" }, onComplete: finish });
      tl = t;

      t.to(glowRef.current, { opacity: 1, duration: 0.6 }, 0.15).to(
        ringRef.current,
        { opacity: 1, scale: 1, duration: 0.8 },
        0.15
      );

      if (paths.length) {
        t.to(
          paths,
          { strokeDashoffset: 0, duration: 0.65, ease: "power2.inOut", stagger: Math.min(0.04, 0.3 / paths.length) },
          0.25
        )
          .to(paths, { fillOpacity: 1, duration: 0.35, ease: "power1.out" }, 0.65)
          .to(paths, { strokeOpacity: 0, duration: 0.35 }, 0.85);
      }

      t.call(() => setDecode(true), [], 0.8)
        .call(
          () => {
            if (statusRef.current) statusRef.current.textContent = "DECODING FUTURE";
          },
          [],
          0.9
        )
        .to(
          counter,
          {
            v: 100,
            duration: 1.45,
            ease: "none",
            onUpdate: () => {
              const shown = counter.v >= 99.5 ? 100 : Math.floor(counter.v / 10) * 10;
              if (countRef.current) countRef.current.textContent = String(shown).padStart(2, "0");
              if (barRef.current) barRef.current.style.transform = `scaleX(${counter.v / 100})`;
            },
          },
          0.25
        )
        // climax at 100%
        .to(logoWrapRef.current, { scale: 1.15, duration: 0.2, ease: "power3.out" }, 1.7)
        .to(glowRef.current, { scale: 1.5, duration: 0.2 }, 1.7)
        .call(() => fx.flash(), [], 1.75)
        // split with shutter panels
        .to(contentRef.current, { opacity: 0, duration: 0.2 }, 1.85)
        .to(
          panels,
          { yPercent: (i: number) => (i % 2 ? 100 : -100), duration: 0.4, ease: "power3.inOut", stagger: 0.04 },
          1.85
        )
        .call(() => motionState.setReady(true), [], 2.1);
    })();

    return () => {
      cancelled = true;
      tl?.kill();
    };
  }, []);

  if (gone) return null;

  return (
    <div className="loader fixed inset-0 z-[10000]" aria-hidden="true">
      <div className="absolute inset-0 flex">
        {Array.from({ length: N }, (_, i) => (
          <div
            key={i}
            ref={(el) => {
              panelRefs.current[i] = el;
            }}
            className="h-full"
            style={{
              width: "calc(100% / 7 + 1px)",
              marginRight: -1,
              flexShrink: 0,
              background: "linear-gradient(180deg,#050507,#0D0915 70%,#150C2B)",
              borderRight: "1px solid rgba(139,92,246,.25)",
            }}
          />
        ))}
      </div>

      <div ref={contentRef} className="absolute inset-0 grid place-items-center">
        <div
          ref={glowRef}
          className="absolute h-[70vmin] w-[70vmin] rounded-full opacity-0"
          style={{ background: "radial-gradient(circle, rgba(139,92,246,.28), transparent 62%)" }}
        />
        <div
          ref={ringRef}
          className="absolute h-[34vmin] w-[34vmin] animate-pulse rounded-full border border-volt/50 opacity-0"
          style={{ transform: "scale(.8)", boxShadow: "0 0 60px rgba(139,92,246,.35), inset 0 0 40px rgba(139,92,246,.2)" }}
        />
        <div className="relative flex flex-col items-center gap-8 px-6">
          <div ref={logoWrapRef} className="h-24 w-24 sm:h-28 sm:w-28">
            <div ref={logoRef} className="h-full w-full" />
          </div>
          <DecodeText
            text="THE DECODERS"
            start={decode}
            hideUntilStart
            duration={900}
            className="font-display text-4xl tracking-[0.18em] text-ink sm:text-5xl"
          />
          <div className="w-[min(70vw,360px)]">
            <div className="h-px w-full bg-white/10">
              <div
                ref={barRef}
                className="h-full origin-left bg-volt-hot"
                style={{ transform: "scaleX(0)", boxShadow: "0 0 14px 2px rgba(168,85,247,.9)" }}
              />
            </div>
            <div className="mt-3 flex items-center justify-between font-mono text-[10px] tracking-[0.3em] text-ash">
              <span ref={statusRef}>INITIALIZING</span>
              <span ref={countRef} className="text-ink">
                00
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
