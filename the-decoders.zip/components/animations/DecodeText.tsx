"use client";
import { useEffect, useRef, useState } from "react";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

const GLYPHS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&@*+<>/\\|=?!ΞΛΨΩΔ▒▓";

type Props = {
  text: string;
  start?: boolean;
  duration?: number;
  className?: string;
  hideUntilStart?: boolean;
};

export default function DecodeText({ text, start = true, duration = 900, className, hideUntilStart = false }: Props) {
  const [out, setOut] = useState(text);
  const raf = useRef(0);

  useEffect(() => {
    if (!start || prefersReducedMotion()) {
      setOut(text);
      return;
    }
    const t0 = performance.now();
    const len = text.length;
    const loop = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      let s = "";
      for (let i = 0; i < len; i++) {
        const ch = text[i];
        if (ch === " ") {
          s += " ";
          continue;
        }
        const resolveAt = (i / len) * 0.75 + 0.25;
        s += p >= resolveAt ? ch : GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      }
      setOut(p >= 1 ? text : s);
      if (p < 1) raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, [start, text, duration]);

  return (
    <span className={className} aria-label={text} style={hideUntilStart ? { opacity: start ? 1 : 0 } : undefined}>
      <span aria-hidden="true">{out}</span>
    </span>
  );
}
