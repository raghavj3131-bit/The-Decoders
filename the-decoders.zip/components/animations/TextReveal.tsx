"use client";
import { useEffect, useRef, useState } from "react";
import { useReady } from "@/lib/motionState";

type Props = {
  text: string;
  by?: "line" | "word" | "char";
  as?: "h1" | "h2" | "h3" | "p" | "div" | "span";
  className?: string;
  delay?: number;
  stagger?: number;
  trigger?: "view" | "ready";
};

export default function TextReveal({
  text,
  by = "word",
  as = "div",
  className,
  delay = 0,
  stagger,
  trigger = "view",
}: Props) {
  const Tag = as as React.ElementType;
  const ref = useRef<HTMLElement>(null);
  const [seen, setSeen] = useState(false);
  const ready = useReady();

  useEffect(() => {
    if (trigger !== "view") return;
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold: 0.25 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [trigger]);

  const shown = trigger === "ready" ? ready : seen;
  const step = stagger ?? (by === "char" ? 0.03 : by === "word" ? 0.07 : 0.12);
  let n = 0;
  const d = () => `${delay + step * n++}s`;

  const lines = text.split("\n");

  return (
    <Tag ref={ref} className={`${shown ? "tr-in" : ""} ${className ?? ""}`} aria-label={text.replace(/\n/g, " ")}>
      {lines.map((line, li) => {
        const words = line.split(" ");
        return (
          <span key={li} aria-hidden="true" className="-mb-[0.1em] block overflow-hidden pb-[0.1em] pr-[0.06em]">
            {by === "line" ? (
              <span className="tr-unit" style={{ transitionDelay: d() }}>
                {line}
              </span>
            ) : (
              words.map((word, wi) => (
                <span key={wi} className="inline-block whitespace-pre">
                  {by === "word" ? (
                    <span className="tr-unit" style={{ transitionDelay: d() }}>
                      {word}
                    </span>
                  ) : (
                    Array.from(word).map((ch, ci) => (
                      <span key={ci} className="tr-unit" style={{ transitionDelay: d() }}>
                        {ch}
                      </span>
                    ))
                  )}
                  {wi < words.length - 1 ? " " : ""}
                </span>
              ))
            )}
          </span>
        );
      })}
    </Tag>
  );
}
