"use client";
import { useEffect, useRef } from "react";
import { scrollState } from "@/lib/scrollState";
import { useReducedMotion } from "@/hooks/useMediaFlags";

// deterministic pseudo-random (SSR-safe)
const rnd = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const BURST = Array.from({ length: 56 }, (_, i) => {
  const a = (i / 56) * Math.PI * 2 + rnd(i) * 0.08;
  const r0 = 18 + rnd(i + 9) * 22;
  const r1 = r0 + 30 + rnd(i + 3) * 70;
  return {
    x1: Math.cos(a) * r0,
    y1: Math.sin(a) * r0,
    x2: Math.cos(a) * r1,
    y2: Math.sin(a) * r1,
    w: rnd(i + 5) > 0.7 ? 0.7 : 0.3,
    hot: rnd(i + 1) > 0.5,
  };
});

const STREAKS = Array.from({ length: 12 }, (_, i) => ({
  top: `${6 + rnd(i + 20) * 88}%`,
  width: `${18 + rnd(i + 30) * 30}vw`,
  delay: `${-rnd(i + 40) * 0.45}s`,
  dur: `${0.32 + rnd(i + 50) * 0.3}s`,
}));

function Burst({ active }: { active: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!active || reduced) return;
    const a = ref.current?.animate(
      [
        { opacity: 0, transform: "scale(0.4)" },
        { opacity: 1, transform: "scale(0.9)", offset: 0.25 },
        { opacity: 0, transform: "scale(1.7)" },
      ],
      { duration: 900, easing: "cubic-bezier(.16,1,.3,1)" }
    );
    return () => a?.cancel();
  }, [active, reduced]);
  return (
    <div ref={ref} aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-0">
      <svg viewBox="-100 -100 200 200" preserveAspectRatio="xMidYMid slice" className="h-full w-full">
        {BURST.map((l, i) => (
          <line
            key={i}
            x1={l.x1}
            y1={l.y1}
            x2={l.x2}
            y2={l.y2}
            strokeWidth={l.w}
            stroke={l.hot ? "#A855F7" : "#F5F5F5"}
            strokeLinecap="round"
          />
        ))}
      </svg>
    </div>
  );
}

function Streaks() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (reduced) return;
    return scrollState.subscribe((v) => {
      const el = ref.current;
      if (!el) return;
      const o = Math.min(1, Math.max(0, (Math.abs(v) - 10) / 30));
      el.style.opacity = String(o);
      el.classList.toggle("on", o > 0);
    });
  }, [reduced]);
  return (
    <div ref={ref} aria-hidden="true" className="streaks">
      {STREAKS.map((s, i) => (
        <span
          key={i}
          className="streak"
          style={{ top: s.top, width: s.width, animationDelay: s.delay, animationDuration: s.dur }}
        />
      ))}
    </div>
  );
}

export default function SpeedLines({ mode, active = false }: { mode: "burst" | "scroll"; active?: boolean }) {
  return mode === "burst" ? <Burst active={active} /> : <Streaks />;
}
