"use client";
import { useEffect, useRef } from "react";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

export default function ImpactFlash() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const on = () => {
      if (prefersReducedMotion()) return;
      ref.current?.animate([{ opacity: 0 }, { opacity: 0.8, offset: 0.15 }, { opacity: 0 }], { duration: 150 });
    };
    window.addEventListener("decoders:flash", on);
    return () => window.removeEventListener("decoders:flash", on);
  }, []);
  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[10100] opacity-0"
      style={{ background: "radial-gradient(circle at 50% 50%, #fff 0%, #A855F7 55%, transparent 100%)" }}
    />
  );
}
