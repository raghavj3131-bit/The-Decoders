"use client";
import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useIsMobile, useReducedMotion } from "@/hooks/useMediaFlags";

export default function ParallaxLayer({
  children,
  speed = 0.3,
  className,
}: {
  children?: React.ReactNode;
  speed?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  const mobile = useIsMobile();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const k = reduced ? 0 : mobile ? speed * 0.4 : speed;
  const y = useTransform(scrollYProgress, [0, 1], [-200 * k, 200 * k]);
  return (
    <div ref={ref} className={className}>
      <motion.div style={{ y }} className="h-full w-full">
        {children}
      </motion.div>
    </div>
  );
}
