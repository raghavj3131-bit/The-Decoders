"use client";

/** One distinct decorative element per page hero. */
export default function HeroDecor({ variant }: { variant: string }) {
  switch (variant) {
    case "about":
      return (
        <div aria-hidden="true" className="absolute bottom-0 right-[12%] top-0 hidden w-px bg-gradient-to-b from-transparent via-volt-hot to-transparent md:block" style={{ boxShadow: "0 0 24px 2px rgba(168,85,247,.7)" }} />
      );
    case "programs":
      return (
        <span aria-hidden="true" className="text-outline-volt pointer-events-none absolute -right-4 bottom-6 font-display text-[clamp(10rem,32vw,30rem)] leading-none opacity-40">08</span>
      );
    case "community":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute right-[-10vmin] top-1/2 h-[80vmin] w-[80vmin] -translate-y-1/2">
          {[1, 0.7, 0.42].map((s, i) => (
            <div key={i} className="absolute inset-0 m-auto rounded-full border border-volt/40" style={{ width: `${s * 100}%`, height: `${s * 100}%`, animation: `spin-slow ${30 + i * 14}s linear infinite ${i % 2 ? "reverse" : ""}` }}>
              <span className="absolute left-1/2 top-0 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-volt-hot" style={{ boxShadow: "0 0 18px 4px rgba(168,85,247,.8)" }} />
            </div>
          ))}
        </div>
      );
    case "opportunities":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 hidden w-1/3 overflow-hidden md:block">
          <div className="absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-volt/25 to-transparent" style={{ animation: "scan 4s linear infinite" }} />
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "linear-gradient(rgba(139,92,246,.35) 1px, transparent 1px)", backgroundSize: "100% 32px" }} />
        </div>
      );
    case "events":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute right-[10%] top-[30%] hidden items-center gap-4 font-mono text-xs tracking-[0.3em] text-volt-hot md:flex">
          <span className="live-dot h-3 w-3 rounded-full bg-volt-hot" /> LIVE ARCHIVE
        </div>
      );
    case "resources":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-25" style={{ backgroundImage: "linear-gradient(rgba(139,92,246,.4) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,.4) 1px, transparent 1px)", backgroundSize: "64px 64px", WebkitMaskImage: "radial-gradient(ellipse at 80% 50%, #000, transparent 65%)", maskImage: "radial-gradient(ellipse at 80% 50%, #000, transparent 65%)" }} />
      );
    case "team":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute bottom-0 right-[6%] hidden gap-3 md:flex">
          {[56, 80, 64].map((h, i) => (
            <div key={i} className="w-20 rounded-t-full border border-volt/40 bg-gradient-to-b from-volt/20 to-transparent" style={{ height: `${h * 3}px` }} />
          ))}
        </div>
      );
    case "stories":
      return (
        <span aria-hidden="true" className="text-outline-volt pointer-events-none absolute right-6 top-24 font-display text-[clamp(10rem,30vw,28rem)] leading-none opacity-30">”</span>
      );
    case "join":
      return (
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-30" style={{ backgroundImage: "repeating-linear-gradient(0deg, rgba(139,92,246,.35) 0 1px, transparent 1px 36px)", WebkitMaskImage: "radial-gradient(ellipse at 70% 50%, #000, transparent 70%)", maskImage: "radial-gradient(ellipse at 70% 50%, #000, transparent 70%)" }} />
      );
    default:
      return null;
  }
}
