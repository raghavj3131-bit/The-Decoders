import { siteConfig } from "@/config/site";
import TransitionLink from "@/components/ui/TransitionLink";
import Halftone from "@/components/effects/Halftone";
import DrawStroke from "@/components/ui/DrawStroke";

export default function Footer() {
  const socials = Object.entries(siteConfig.links);
  const year = new Date().getUTCFullYear();
  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-night">
      <Halftone opacity={0.12} x="20%" y="100%" size={16} />
      <div className="relative mx-auto max-w-[1500px] px-5 pb-10 pt-20 md:px-12">
        <p className="font-display text-[clamp(3.5rem,13vw,12rem)] leading-[0.85] text-ink">THE DECODERS</p>
        <div className="mt-4 flex items-center gap-4">
          <p className="font-mono text-xs tracking-[0.3em] text-volt-hot">DECODE YOUR FUTURE.</p>
          <DrawStroke />
        </div>

        <div className="mt-16 grid gap-12 md:grid-cols-3">
          <nav aria-label="Footer">
            <p className="mb-4 font-mono text-[11px] tracking-[0.3em] text-ash">NAVIGATION</p>
            <ul className="grid grid-cols-2 gap-x-6 gap-y-2 font-mono text-xs tracking-[0.2em]">
              {siteConfig.nav.map((n) => (
                <li key={n.href}>
                  <TransitionLink href={n.href} className="text-ink/80 transition-colors hover:text-volt-hot">
                    {n.label}
                  </TransitionLink>
                </li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="mb-4 font-mono text-[11px] tracking-[0.3em] text-ash">SOCIAL</p>
            <ul className="space-y-2 font-mono text-xs uppercase tracking-[0.2em]">
              {socials.map(([k, v]) => (
                <li key={k}>
                  {v ? (
                    <a href={v} target="_blank" rel="noopener noreferrer" className="text-ink/80 transition-colors hover:text-volt-hot">
                      {k}
                    </a>
                  ) : (
                    <span className="text-ash/50">{k} · soon</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="mb-4 font-mono text-[11px] tracking-[0.3em] text-ash">CONTACT</p>
            {siteConfig.contact.email ? (
              <a href={`mailto:${siteConfig.contact.email}`} className="font-mono text-xs tracking-[0.15em] text-ink/80 hover:text-volt-hot">
                {siteConfig.contact.email}
              </a>
            ) : (
              <TransitionLink href="/join" className="font-mono text-xs tracking-[0.2em] text-ink/80 hover:text-volt-hot">
                REQUEST ACCESS →
              </TransitionLink>
            )}
          </div>
        </div>

        <div className="mt-16 flex flex-col justify-between gap-2 border-t border-white/10 pt-6 font-mono text-[10px] tracking-[0.25em] text-ash md:flex-row">
          <span>© {year} THE DECODERS. ALL RIGHTS RESERVED.</span>
          <span>SYSTEM 01 // STATUS: ONLINE // LOCATION: EVERYWHERE</span>
        </div>
      </div>
    </footer>
  );
}
