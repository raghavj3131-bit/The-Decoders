"use client";
import TextReveal from "@/components/animations/TextReveal";
import Halftone from "@/components/effects/Halftone";
import SectionLabel from "@/components/ui/SectionLabel";
import ParallaxLayer from "@/components/animations/ParallaxLayer";
import HeroDecor from "./HeroDecor";
import { useReady } from "@/lib/motionState";

type Props = {
  system: string; // e.g. "SYSTEM 02 // ABOUT"
  lines: string[];
  variant: string;
  align?: "left" | "right" | "center";
  outlineLast?: boolean;
  sub?: string;
  skew?: boolean;
};

export default function PageHero({ system, lines, variant, align = "left", outlineLast = true, sub, skew = false }: Props) {
  const ready = useReady();
  const alignCls = align === "right" ? "items-end text-right" : align === "center" ? "items-center text-center" : "items-start text-left";
  return (
    <section className="relative flex min-h-[92svh] items-end overflow-hidden pb-16 pt-36 md:pb-24">
      <ParallaxLayer speed={0.25} className="absolute inset-0">
        <div className="absolute -left-1/4 top-0 h-[80%] w-[80%] rounded-full bg-volt-deep/20 blur-[140px]" />
      </ParallaxLayer>
      <Halftone opacity={0.14} x={align === "right" ? "20%" : "75%"} y="40%" />
      <HeroDecor variant={variant} />
      <div className={`relative z-10 mx-auto flex w-full max-w-[1500px] flex-col gap-6 px-5 md:px-12 ${alignCls}`}>
        <SectionLabel className={`hero-fade ${ready ? "is-in" : ""}`}>{system}</SectionLabel>
        <h1
          className="font-display text-[clamp(3.4rem,min(14vw,17svh),13rem)] leading-[0.86]"
          style={skew ? { transform: "skewX(-6deg)" } : undefined}
          aria-label={lines.join(" ")}
        >
          {lines.map((l, i) => {
            const last = i === lines.length - 1;
            return (
              <TextReveal
                key={i}
                text={l}
                by="char"
                as="span"
                trigger="ready"
                delay={i * 0.14}
                stagger={0.025}
                className={`block ${last && outlineLast ? "text-outline-volt" : "text-ink"}`}
              />
            );
          })}
        </h1>
        {sub && (
          <p className={`hero-fade max-w-xl text-base text-ash md:text-lg ${ready ? "is-in" : ""}`} style={{ transitionDelay: "0.6s" }}>
            {sub}
          </p>
        )}
      </div>
    </section>
  );
}
