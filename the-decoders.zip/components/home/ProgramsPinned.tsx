"use client";
import { useEffect, useRef } from "react";
import { programs } from "@/data/programs";
import TiltCard from "@/components/ui/TiltCard";
import ProgramVisual from "@/components/ui/ProgramVisual";
import MagneticButton from "@/components/ui/MagneticButton";
import SectionLabel from "@/components/ui/SectionLabel";

export default function ProgramsPinned() {
  const section = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    let revert: (() => void) | undefined;

    (async () => {
      const { gsap } = await import("gsap");
      const { ScrollTrigger } = await import("gsap/ScrollTrigger");
      if (cancelled) return;
      gsap.registerPlugin(ScrollTrigger);

      const mm = gsap.matchMedia();
      mm.add("(min-width: 1024px) and (prefers-reduced-motion: no-preference)", () => {
        const el = track.current;
        const sec = section.current;
        if (!el || !sec) return;
        const dist = () => Math.max(0, el.scrollWidth - window.innerWidth);
        gsap.to(el, {
          x: () => -dist(),
          ease: "none",
          scrollTrigger: {
            trigger: sec,
            pin: true,
            scrub: 0.6,
            start: "top top",
            end: () => `+=${dist()}`,
            invalidateOnRefresh: true,
            anticipatePin: 1,
          },
        });
      });
      revert = () => mm.revert();
    })();

    return () => {
      cancelled = true;
      revert?.();
    };
  }, []);

  return (
    <section ref={section} id="programs" className="relative overflow-hidden py-24 lg:flex lg:h-screen lg:items-center lg:py-0">
      <div ref={track} className="flex flex-col gap-5 px-5 md:px-12 lg:w-max lg:flex-row lg:items-stretch lg:gap-6">
        <div className="flex shrink-0 flex-col justify-center pb-6 lg:w-[30vw] lg:pb-0 lg:pr-10">
          <SectionLabel className="mb-6">SYSTEM 04 // PROGRAMS</SectionLabel>
          <h2 className="font-display text-[clamp(3rem,7vw,7rem)] leading-[0.9] text-ink">
            EIGHT WAYS
            <br />
            <span className="text-outline-volt">TO DECODE.</span>
          </h2>
          <p className="mt-6 max-w-sm text-ash">Pick a track. Learn by building. Scroll to explore all eight.</p>
        </div>

        {programs.map((p) => (
          <TiltCard key={p.id} className="lg:h-[64vh] lg:w-[30vw] lg:max-w-[520px] lg:shrink-0" innerClassName="flex h-full flex-col justify-between gap-8 rounded-2xl border border-white/10 bg-abyss/80 p-7 backdrop-blur-sm lg:p-9">
            <div className="flex items-start justify-between">
              <span className="font-mono text-xs tracking-[0.3em] text-volt-hot">{p.number}</span>
              <ProgramVisual id={p.id} className="h-28 w-28 lg:h-36 lg:w-36" />
            </div>
            <div>
              <h3 className="font-display text-[clamp(2.2rem,4vw,3.6rem)] leading-none text-ink">{p.title}</h3>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-ash">{p.description}</p>
              <div className="mt-6">
                <MagneticButton href="/programs" variant="ghost" className="!min-h-[44px] !px-5 !py-3">
                  VIEW PROGRAM →
                </MagneticButton>
              </div>
            </div>
          </TiltCard>
        ))}
        <div className="shrink-0 lg:w-[10vw]" aria-hidden="true" />
      </div>
    </section>
  );
}
