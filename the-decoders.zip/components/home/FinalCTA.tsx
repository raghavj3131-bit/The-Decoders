"use client";
import TextReveal from "@/components/animations/TextReveal";
import ParallaxLayer from "@/components/animations/ParallaxLayer";
import MagneticButton from "@/components/ui/MagneticButton";
import Halftone from "@/components/effects/Halftone";

export default function FinalCTA() {
  return (
    <section className="relative flex min-h-[100svh] items-center overflow-hidden py-28">
      <ParallaxLayer speed={0.5} className="absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[90vmin] w-[90vmin] -translate-x-1/2 -translate-y-1/2 rounded-full bg-volt-deep/30 blur-[140px]" />
      </ParallaxLayer>
      <Halftone opacity={0.16} x="50%" y="50%" size={16} />
      <div className="relative z-10 mx-auto w-full max-w-[1500px] px-5 md:px-12">
        <TextReveal
          as="h2"
          by="word"
          text={"THE FUTURE\nIS WAITING\nTO BE\nDECODED."}
          className="font-display text-[clamp(3.4rem,13vw,12rem)] leading-[0.88] text-ink"
        />
        <div className="mt-12">
          <MagneticButton href="/join" variant="primary" className="!px-10 !py-5 text-sm">
            JOIN THE DECODERS →
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
