"use client";
import { identityCards } from "@/data/home";
import TiltCard from "@/components/ui/TiltCard";
import SectionLabel from "@/components/ui/SectionLabel";
import TextReveal from "@/components/animations/TextReveal";
import Halftone from "@/components/effects/Halftone";

const POS = [
  { l: "6%", t: "8%", r: "-4deg", d: "0s" },
  { l: "34%", t: "2%", r: "3deg", d: "-1.2s" },
  { l: "62%", t: "10%", r: "-2deg", d: "-2.4s" },
  { l: "14%", t: "46%", r: "3deg", d: "-3.1s" },
  { l: "44%", t: "42%", r: "-3deg", d: "-4.2s" },
  { l: "72%", t: "50%", r: "4deg", d: "-5s" },
  { l: "30%", t: "76%", r: "-2deg", d: "-1.8s" },
];

export default function CommunitySection() {
  return (
    <section className="relative overflow-hidden bg-night py-28 md:py-40">
      <Halftone opacity={0.1} x="50%" y="50%" size={18} />
      <div className="relative mx-auto max-w-[1500px] px-5 md:px-12">
        <SectionLabel className="mb-6">SYSTEM 06 // COMMUNITY</SectionLabel>
        <TextReveal as="h2" by="word" text="FIND YOUR PEOPLE." className="font-display text-[clamp(3.2rem,10vw,9rem)] leading-[0.9] text-ink" />

        {/* desktop: floating cards */}
        <div className="relative mt-16 hidden h-[56vh] md:block">
          {identityCards.map((c, i) => (
            <div key={c} className="float-card absolute" style={{ left: POS[i].l, top: POS[i].t, ["--r" as string]: POS[i].r, animationDelay: POS[i].d }}>
              <TiltCard innerClassName="rounded-xl border border-white/10 bg-abyss/90 px-8 py-6 backdrop-blur-sm">
                <span className="font-display text-3xl text-ink lg:text-4xl">{c}</span>
              </TiltCard>
            </div>
          ))}
        </div>

        {/* mobile: stacked chips */}
        <ul className="mt-12 flex flex-wrap gap-3 md:hidden">
          {identityCards.map((c) => (
            <li key={c} className="rounded-xl border border-white/10 bg-abyss px-5 py-4 font-display text-2xl text-ink">
              {c}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
