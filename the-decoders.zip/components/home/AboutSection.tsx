"use client";
import TextReveal from "@/components/animations/TextReveal";
import ParallaxLayer from "@/components/animations/ParallaxLayer";
import Halftone from "@/components/effects/Halftone";
import SectionLabel from "@/components/ui/SectionLabel";

export default function AboutSection() {
  return (
    <section id="about" className="relative flex min-h-[110svh] items-center overflow-hidden py-32">
      <ParallaxLayer speed={0.6} className="absolute inset-0">
        <div className="absolute right-[-10%] top-[10%] h-[70vmin] w-[70vmin] rounded-full bg-volt-deep/25 blur-[120px]" />
      </ParallaxLayer>
      <ParallaxLayer speed={-0.3} className="absolute inset-0">
        <Halftone opacity={0.2} x="20%" y="60%" size={16} />
      </ParallaxLayer>
      <div className="relative z-10 mx-auto w-full max-w-[1500px] px-5 md:px-12">
        <SectionLabel className="mb-10">SYSTEM 02 // WHO WE ARE</SectionLabel>
        <TextReveal
          as="h2"
          by="word"
          text={"WE DON'T\nPREDICT\nTHE FUTURE."}
          className="font-display text-[clamp(3.4rem,13vw,12rem)] leading-[0.88] text-ink"
        />
        <TextReveal
          as="p"
          by="word"
          delay={0.3}
          text="WE DECODE IT."
          className="mt-8 font-display text-[clamp(3rem,11vw,10rem)] leading-[0.9] text-volt-hot glow-text"
        />
      </div>
    </section>
  );
}
