"use client";
import { events } from "@/data/events";
import { formatDate } from "@/lib/format";
import { useInView } from "@/hooks/useInView";
import SectionLabel from "@/components/ui/SectionLabel";
import MagneticButton from "@/components/ui/MagneticButton";
import TextReveal from "@/components/animations/TextReveal";

function Row({ i, e }: { i: number; e: (typeof events)[number] }) {
  const [ref, seen] = useInView<HTMLLIElement>(0.3);
  return (
    <li ref={ref} className={`rv-wipe ${seen ? "is-in" : ""} group border-b border-white/10 py-7 transition-colors hover:bg-volt/5`}>
      <div className="grid items-baseline gap-x-8 gap-y-2 md:grid-cols-[6rem_9rem_1fr_9rem]">
        <span className="font-display text-5xl text-outline-volt md:text-6xl">{String(i + 1).padStart(2, "0")}</span>
        <span className="font-mono text-xs tracking-[0.2em] text-ash">{formatDate(e.date)}</span>
        <div>
          <h3 className="font-display text-3xl leading-tight text-ink transition-transform duration-500 group-hover:translate-x-2 md:text-4xl">{e.title}</h3>
          <p className="mt-2 max-w-xl text-sm text-ash">{e.description}</p>
        </div>
        <span className="font-mono text-[11px] tracking-[0.25em] text-volt-hot md:text-right">{e.category}</span>
      </div>
    </li>
  );
}

export default function EventsArchive() {
  const list = [...events].sort((a, b) => (a.status === b.status ? a.date.localeCompare(b.date) : a.status === "upcoming" ? -1 : 1)).slice(0, 5);
  return (
    <section className="relative py-28 md:py-40">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <SectionLabel className="mb-6">SYSTEM 05 // EVENT ARCHIVE</SectionLabel>
        <TextReveal as="h2" by="word" text={"THE MOMENTS\nTHAT MATTER."} className="mb-14 font-display text-[clamp(3rem,9vw,8rem)] leading-[0.9] text-ink" />
        <ol className="border-t border-white/10">
          {list.map((e, i) => (
            <Row key={e.id} i={i} e={e} />
          ))}
        </ol>
        <div className="mt-12">
          <MagneticButton href="/events" variant="ghost">
            FULL ARCHIVE →
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
