"use client";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import Halftone from "@/components/effects/Halftone";
import SpeedLines from "@/components/animations/SpeedLines";
import MagneticButton from "@/components/ui/MagneticButton";
import { useReady } from "@/lib/motionState";
import { useIsDesktop, useIsMobile, useReducedMotion } from "@/hooks/useMediaFlags";

const ParticleField = dynamic(() => import("@/components/effects/ParticleField"), { ssr: false });

export default function Hero() {
  const ready = useReady();
  const reduced = useReducedMotion();
  const mobile = useIsMobile();
  const desktop = useIsDesktop();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const particles = mounted && !reduced && !mobile ? (desktop ? 700 : 250) : 0;

  return (
    <section className={`relative flex min-h-[100svh] items-center overflow-hidden ${ready ? "is-in" : ""}`}>
      <div className="absolute inset-0 -z-0 bg-[radial-gradient(ellipse_at_70%_30%,rgba(124,58,237,.22),transparent_60%)]" />
      <Halftone opacity={0.15} x="75%" y="35%" size={14} />
      {particles > 0 && <ParticleField count={particles} />}
      <SpeedLines mode="burst" active={ready} />

      <div className="relative z-10 mx-auto w-full max-w-[1500px] px-5 pb-16 pt-32 md:px-12">
        <p className="hero-fade mb-6 font-mono text-[11px] tracking-[0.3em] text-ash">THE DECODERS // SYSTEM 01</p>

        <h1 className="hero-h" aria-label="Decode your future">
          <span className="hero-mask" aria-hidden="true">
            <span className="hero-w hero-w1 text-ink">DECODE</span>
          </span>
          <span className="hero-mask" aria-hidden="true">
            <span className="hero-w hero-w2 text-outline-white">YOUR</span>
          </span>
          <span className="hero-free" aria-hidden="true">
            <span className="hero-w hero-w3 glow-text text-volt-hot">FUTURE</span>
          </span>
        </h1>

        <p className="hero-fade mt-8 max-w-xl text-base leading-relaxed text-ink/80 md:text-lg" style={{ transitionDelay: "0.9s" }}>
          A COMMUNITY FOR PEOPLE WHO
          <br />
          DON&apos;T JUST FOLLOW THE FUTURE —
          <br />
          THEY DECODE IT.
        </p>

        <div className="hero-fade mt-10 flex flex-wrap items-center gap-4" style={{ transitionDelay: "1.1s" }}>
          <MagneticButton href="/join" variant="primary">
            ENTER THE DECODERS →
          </MagneticButton>
          <MagneticButton href="#about" variant="ghost">
            EXPLORE ↓
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
