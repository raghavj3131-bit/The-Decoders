import { siteConfig } from "@/config/site";
import Counter from "@/components/ui/Counter";
import SectionLabel from "@/components/ui/SectionLabel";

export default function Numbers() {
  return (
    <section className="relative border-y border-white/10 bg-night py-24 md:py-32">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <SectionLabel className="mb-12">SYSTEM 03 // THE SIGNAL</SectionLabel>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-14 lg:grid-cols-4">
          {siteConfig.stats.map((s) => (
            <div key={s.key} className="flex flex-col-reverse border-l border-volt/40 pl-5">
              <dt className="mt-3 font-mono text-[11px] tracking-[0.3em] text-ash">{s.label}</dt>
              <dd className="font-display text-[clamp(3.4rem,10vw,9rem)] leading-none text-ink">
                <Counter value={s.value} suffix={s.suffix} />
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
