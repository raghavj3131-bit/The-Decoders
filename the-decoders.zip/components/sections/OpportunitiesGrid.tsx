"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { opportunities, opportunityCategories, type OpportunityCategory } from "@/data/opportunities";
import { formatDate } from "@/lib/format";
import Tabs from "@/components/ui/Tabs";
import TiltCard from "@/components/ui/TiltCard";
import MagneticButton from "@/components/ui/MagneticButton";

type Cat = (typeof opportunityCategories)[number];

export default function OpportunitiesGrid() {
  const [cat, setCat] = useState<Cat>("ALL");
  const list = cat === "ALL" ? opportunities : opportunities.filter((o) => o.category === (cat as OpportunityCategory));

  return (
    <section className="relative py-20 md:py-28">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <Tabs tabs={opportunityCategories} value={cat} onChange={setCat} label="Filter opportunities" />
          <p className="font-mono text-[11px] tracking-[0.3em] text-ash" aria-live="polite">
            {list.length} {list.length === 1 ? "RESULT" : "RESULTS"}
          </p>
        </div>

        <motion.ul layout className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {list.map((o) => (
              <motion.li
                key={o.id}
                layout
                initial={{ opacity: 0, scale: 0.94, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <TiltCard className="h-full" innerClassName="flex h-full flex-col rounded-2xl border border-white/10 bg-abyss p-6">
                  <div className="flex items-center justify-between font-mono text-[11px] tracking-[0.25em]">
                    <span className="text-volt-hot">{o.category}</span>
                    <span className="text-ash">DEADLINE {formatDate(o.deadline)}</span>
                  </div>
                  <h3 className="mt-6 font-display text-3xl leading-tight text-ink">{o.title}</h3>
                  <p className="mt-2 font-mono text-[11px] tracking-[0.2em] text-ash">
                    {o.organization.toUpperCase()} / {o.location.toUpperCase()}
                  </p>
                  <p className="mt-4 flex-1 text-sm leading-relaxed text-ink/75">{o.description}</p>
                  <div className="mt-6">
                    <MagneticButton href="/join" variant="ghost" className="!min-h-[44px] !px-5 !py-3">
                      GET ACCESS →
                    </MagneticButton>
                  </div>
                </TiltCard>
              </motion.li>
            ))}
          </AnimatePresence>
        </motion.ul>
      </div>
    </section>
  );
}
