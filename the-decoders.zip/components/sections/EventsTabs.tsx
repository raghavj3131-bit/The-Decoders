"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { events } from "@/data/events";
import { formatDate } from "@/lib/format";
import Tabs from "@/components/ui/Tabs";

const TABS = ["UPCOMING", "PAST"] as const;
type Tab = (typeof TABS)[number];

export default function EventsTabs() {
  const [tab, setTab] = useState<Tab>("UPCOMING");
  const list = events
    .filter((e) => e.status === tab.toLowerCase())
    .sort((a, b) => (tab === "UPCOMING" ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date)));

  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <Tabs tabs={TABS} value={tab} onChange={setTab} label="Event timeframe" className="mb-10" />
        <AnimatePresence mode="wait">
          <motion.ol
            key={tab}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="border-t border-white/10"
          >
            {list.length === 0 && <li className="py-10 text-ash">Nothing here yet. Check back soon.</li>}
            {list.map((e, i) => (
              <li key={e.id} className="group border-b border-white/10 py-8 transition-colors hover:bg-volt/5">
                <div className="grid items-baseline gap-x-8 gap-y-3 md:grid-cols-[6rem_10rem_1fr_11rem]">
                  <span className="font-display text-6xl text-outline-volt">{String(i + 1).padStart(2, "0")}</span>
                  <span className="font-mono text-xs tracking-[0.2em] text-ash">{formatDate(e.date)}</span>
                  <div>
                    <h3 className="font-display text-3xl leading-tight text-ink transition-transform duration-500 group-hover:translate-x-2 md:text-5xl">{e.title}</h3>
                    <p className="mt-2 max-w-xl text-sm text-ash">{e.description}</p>
                    <p className="mt-3 font-mono text-[11px] tracking-[0.25em] text-ash">
                      {e.category} / {e.location.toUpperCase()}
                    </p>
                  </div>
                  <span className="flex items-center gap-3 font-mono text-[11px] tracking-[0.25em] md:justify-end">
                    {e.status === "upcoming" ? (
                      <>
                        <span className="live-dot h-2.5 w-2.5 rounded-full bg-volt-hot" aria-hidden="true" />
                        <span className="text-volt-hot">UPCOMING</span>
                      </>
                    ) : (
                      <span className="text-ash">COMPLETED</span>
                    )}
                  </span>
                </div>
              </li>
            ))}
          </motion.ol>
        </AnimatePresence>
      </div>
    </section>
  );
}
