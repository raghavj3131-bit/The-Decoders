"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { resources, resourceTabs, type ResourceTab } from "@/data/resources";
import Tabs from "@/components/ui/Tabs";
import TiltCard from "@/components/ui/TiltCard";
import MagneticButton from "@/components/ui/MagneticButton";

export default function ResourcesTabs() {
  const [tab, setTab] = useState<ResourceTab>("ROADMAPS");
  const list = resources.filter((r) => r.tab === tab);

  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <Tabs tabs={resourceTabs} value={tab} onChange={setTab} label="Resource type" className="mb-10" />
        <AnimatePresence mode="wait">
          <motion.ul
            key={tab}
            role="tabpanel"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
          >
            {list.map((r) => (
              <li key={r.id}>
                <TiltCard className="h-full" innerClassName="flex h-full flex-col rounded-2xl border border-white/10 bg-abyss p-6">
                  <div className="flex items-center justify-between font-mono text-[11px] tracking-[0.25em]">
                    <span className="text-volt-hot">{r.category}</span>
                    <span className="text-ash">{r.difficulty}</span>
                  </div>
                  <h3 className="mt-6 font-display text-3xl leading-tight text-ink">{r.title}</h3>
                  <p className="mt-4 flex-1 text-sm leading-relaxed text-ink/75">{r.description}</p>
                  <div className="mt-6">
                    <MagneticButton href={r.href ?? "/join"} variant="ghost" cta={false} className="!min-h-[44px] !px-5 !py-3">
                      {r.href ? "OPEN →" : "REQUEST ACCESS →"}
                    </MagneticButton>
                  </div>
                </TiltCard>
              </li>
            ))}
          </motion.ul>
        </AnimatePresence>
      </div>
    </section>
  );
}
