"use client";
import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { timeline, mission, vision, values } from "@/data/about";
import { useInView } from "@/hooks/useInView";
import SectionLabel from "@/components/ui/SectionLabel";
import TextReveal from "@/components/animations/TextReveal";
import MagneticButton from "@/components/ui/MagneticButton";

function Item({ n, title, text, i }: { n: string; title: string; text: string; i: number }) {
  const [ref, seen] = useInView<HTMLLIElement>(0.4);
  const right = i % 2 === 1;
  return (
    <li ref={ref} className={`relative pl-12 md:grid md:grid-cols-2 md:pl-0 ${seen ? "is-in" : ""}`}>
      <span
        aria-hidden="true"
        className={`absolute left-[7px] top-3 h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-volt-hot bg-void transition-all duration-700 md:left-1/2 ${seen ? "scale-100 shadow-[0_0_24px_6px_rgba(168,85,247,.7)]" : "scale-50"}`}
      />
      <div className={`rv-wipe ${seen ? "is-in" : ""} ${right ? "md:col-start-2 md:pl-16" : "md:pr-16 md:text-right"}`}>
        <p className="font-mono text-xs tracking-[0.3em] text-volt-hot">{n} // {title}</p>
        <p className="mt-3 max-w-md text-lg text-ink/85 md:inline-block">{text}</p>
      </div>
    </li>
  );
}

export default function AboutTimeline() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 70%", "end 60%"] });
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 24 });

  return (
    <>
      <section className="relative py-28 md:py-40">
        <div className="mx-auto max-w-[1200px] px-5 md:px-12">
          <SectionLabel className="mb-16">STORY TIMELINE // SYSTEM LOG</SectionLabel>
          <div ref={ref} className="relative">
            <div aria-hidden="true" className="absolute bottom-0 left-[7px] top-0 w-px bg-white/10 md:left-1/2" />
            <motion.div
              aria-hidden="true"
              className="absolute bottom-0 left-[7px] top-0 w-px origin-top bg-volt-hot md:left-1/2"
              style={{ scaleY, boxShadow: "0 0 18px 2px rgba(168,85,247,.8)" }}
            />
            <ol className="space-y-24 md:space-y-32">
              {timeline.map((t, i) => (
                <Item key={t.n} {...t} i={i} />
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="border-y border-white/10 bg-night py-24 md:py-32">
        <div className="mx-auto grid max-w-[1500px] gap-16 px-5 md:grid-cols-2 md:px-12">
          <div>
            <SectionLabel className="mb-5">MISSION</SectionLabel>
            <TextReveal as="p" by="word" text={mission} className="font-display text-[clamp(2rem,4.5vw,4rem)] leading-[1] text-ink" />
          </div>
          <div>
            <SectionLabel className="mb-5">VISION</SectionLabel>
            <TextReveal as="p" by="word" delay={0.15} text={vision} className="font-display text-[clamp(2rem,4.5vw,4rem)] leading-[1] text-ink" />
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[1500px] px-5 md:px-12">
          <SectionLabel className="mb-10">VALUES</SectionLabel>
          <ul className="divide-y divide-white/10 border-y border-white/10">
            {values.map((v, i) => (
              <li key={v} className="group flex items-baseline justify-between gap-6 py-6 transition-colors hover:bg-volt/5">
                <span className="font-display text-[clamp(2.5rem,8vw,7rem)] leading-none text-ink transition-transform duration-500 group-hover:translate-x-4">{v}</span>
                <span className="font-mono text-xs tracking-[0.3em] text-volt-hot">{String(i + 1).padStart(2, "0")}</span>
              </li>
            ))}
          </ul>
          <div className="mt-14">
            <MagneticButton href="/join">JOIN THE DECODERS →</MagneticButton>
          </div>
        </div>
      </section>
    </>
  );
}
