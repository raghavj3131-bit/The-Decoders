"use client";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { stories, type Story } from "@/data/stories";
import PlaceholderArt from "@/components/ui/PlaceholderArt";
import { scrollState } from "@/lib/scrollState";

function Art({ s, className }: { s: Story; className: string }) {
  return s.image ? (
    <Image src={s.image} alt={s.name} width={800} height={1000} className={`${className} object-cover`} />
  ) : (
    <PlaceholderArt seed={s.id} className={className} label="IMAGE SOON" />
  );
}

export default function StoriesMasonry() {
  const [open, setOpen] = useState<Story | null>(null);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const opener = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    scrollState.lenis?.stop();
    document.body.style.overflow = "hidden";
    closeBtn.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      scrollState.lenis?.start();
      document.body.style.overflow = "";
      opener.current?.focus();
    };
  }, [open]);

  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <p className="mb-8 max-w-xl text-sm text-ash">Placeholder stories. Replace data/stories.ts with real, consented member stories before publishing.</p>
        <ul className="columns-1 gap-5 sm:columns-2 lg:columns-3">
          {stories.map((s) => (
            <li key={s.id} className="mb-5 break-inside-avoid">
              <button
                type="button"
                data-cursor="card"
                onClick={(e) => {
                  opener.current = e.currentTarget;
                  setOpen(s);
                }}
                className="group relative block w-full overflow-hidden rounded-2xl border border-white/10 text-left transition-[border-color,box-shadow] duration-500 hover:border-volt-hot hover:shadow-[0_0_50px_rgba(139,92,246,.35)]"
                aria-label={`Open story: ${s.name}`}
              >
                <Art s={s} className={`w-full transition-transform duration-700 group-hover:scale-110 ${s.tall ? "aspect-[3/4]" : "aspect-[4/3]"}`} />
                <div className="absolute inset-0 bg-gradient-to-t from-void via-void/40 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 transition-transform duration-500 group-hover:-translate-y-2">
                  <p className="font-mono text-[11px] tracking-[0.25em] text-volt-hot">{s.category} / {s.year}</p>
                  <h3 className="mt-2 font-display text-3xl leading-none text-ink">{s.name}</h3>
                  <p className="mt-2 text-sm text-ink/75">{s.achievement}</p>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[8200] flex items-center justify-center bg-void/90 p-4 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(null)}
            role="dialog"
            aria-modal="true"
            aria-label={`Story: ${open.name}`}
          >
            <motion.div
              initial={{ scale: 0.92, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="grid max-h-[90svh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-volt/50 bg-abyss shadow-[0_0_80px_rgba(139,92,246,.35)] md:grid-cols-2"
              data-lenis-prevent
            >
              <Art s={open} className="aspect-[4/3] w-full md:aspect-auto md:h-full" />
              <div className="flex flex-col justify-center p-8 md:p-10">
                <p className="font-mono text-[11px] tracking-[0.25em] text-volt-hot">{open.category} / {open.year}</p>
                <h3 className="mt-3 font-display text-5xl leading-none text-ink">{open.name}</h3>
                <p className="mt-3 font-mono text-xs tracking-[0.15em] text-ash">{open.achievement.toUpperCase()}</p>
                <p className="mt-8 border-l-2 border-volt pl-5 text-lg leading-relaxed text-ink/90">“{open.quote}”</p>
                <button ref={closeBtn} type="button" onClick={() => setOpen(null)} className="mt-10 self-start border border-white/25 px-6 py-3 font-mono text-[11px] tracking-[0.25em] text-ink transition-colors hover:border-volt-hot">
                  CLOSE
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
