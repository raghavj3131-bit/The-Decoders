"use client";
import Image from "next/image";
import { coreTeam, mentors, type Person } from "@/data/team";
import TiltCard from "@/components/ui/TiltCard";
import PlaceholderArt from "@/components/ui/PlaceholderArt";
import SectionLabel from "@/components/ui/SectionLabel";

function Card({ p }: { p: Person }) {
  const socials = Object.entries(p.socials).filter(([, v]) => v);
  return (
    <TiltCard className="h-full" innerClassName="flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-abyss">
      {p.photo ? (
        <Image src={p.photo} alt={p.name} width={600} height={600} className="aspect-square w-full object-cover" />
      ) : (
        <PlaceholderArt seed={p.id + p.role} className="aspect-square w-full" label="PHOTO SOON" />
      )}
      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-display text-3xl leading-none text-ink">{p.name}</h3>
        <p className="mt-2 font-mono text-[11px] tracking-[0.25em] text-volt-hot">{p.role.toUpperCase()}</p>
        <p className="mt-4 flex-1 text-sm leading-relaxed text-ash">{p.bio}</p>
        {socials.length > 0 && (
          <ul className="mt-5 flex gap-4 font-mono text-[11px] uppercase tracking-[0.2em]">
            {socials.map(([k, v]) => (
              <li key={k}>
                <a href={v} target="_blank" rel="noopener noreferrer" className="text-ink/80 hover:text-volt-hot">
                  {k}
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </TiltCard>
  );
}

function Group({ title, people }: { title: string; people: Person[] }) {
  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-[1500px] px-5 md:px-12">
        <SectionLabel className="mb-8">{title}</SectionLabel>
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {people.map((p) => (
            <li key={p.id}>
              <Card p={p} />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export default function TeamGrid() {
  return (
    <>
      <Group title="CORE TEAM" people={coreTeam} />
      <Group title="MENTORS" people={mentors} />
    </>
  );
}
