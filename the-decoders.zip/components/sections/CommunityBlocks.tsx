"use client";
import { identities, groups, perks, rules } from "@/data/community";
import TiltCard from "@/components/ui/TiltCard";
import SectionLabel from "@/components/ui/SectionLabel";
import GlowingBorder from "@/components/ui/GlowingBorder";
import MagneticButton from "@/components/ui/MagneticButton";
import Halftone from "@/components/effects/Halftone";
import { useInView } from "@/hooks/useInView";

function Rule({ n, t }: { n: string; t: string }) {
  const [ref, seen] = useInView<HTMLLIElement>(0.4);
  return (
    <li ref={ref} className={`rv-wipe ${seen ? "is-in" : ""} flex items-baseline gap-6 border-b border-white/10 py-6 md:gap-12`}>
      <span className="font-display text-5xl text-outline-volt md:text-7xl">{n}</span>
      <span className="font-display text-[clamp(1.8rem,5vw,4.5rem)] leading-none text-ink">{t}</span>
    </li>
  );
}

export default function CommunityBlocks() {
  return (
    <>
      <section className="relative py-24 md:py-32">
        <div className="mx-auto max-w-[1500px] px-5 md:px-12">
          <SectionLabel className="mb-10">WHO YOU MIGHT BE</SectionLabel>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {identities.map((c) => (
              <TiltCard key={c.title} className="h-full" innerClassName="flex h-full min-h-[240px] flex-col justify-between rounded-2xl border border-white/10 bg-abyss p-7">
                <h3 className="font-display text-4xl leading-none text-ink">{c.title}</h3>
                <p className="mt-10 text-sm leading-relaxed text-ash">{c.text}</p>
              </TiltCard>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden border-y border-white/10 bg-night py-24 md:py-32">
        <Halftone opacity={0.1} x="85%" y="20%" />
        <div className="relative mx-auto grid max-w-[1500px] gap-16 px-5 md:grid-cols-2 md:px-12">
          <div>
            <SectionLabel className="mb-8">GROUPS</SectionLabel>
            <ul className="space-y-4">
              {groups.map((g) => (
                <li key={g.title}>
                  <GlowingBorder className="rounded-xl bg-abyss/70 p-6">
                    <h3 className="font-display text-3xl text-ink">{g.title}</h3>
                    <p className="mt-2 text-sm text-ash">{g.text}</p>
                  </GlowingBorder>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SectionLabel className="mb-8">PERKS</SectionLabel>
            <ul className="divide-y divide-white/10 border-y border-white/10">
              {perks.map((p) => (
                <li key={p} className="flex items-center gap-4 py-5 text-lg text-ink/90">
                  <span className="h-px w-8 bg-volt-hot" aria-hidden="true" />
                  {p}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="py-24 md:py-32">
        <div className="mx-auto max-w-[1500px] px-5 md:px-12">
          <SectionLabel className="mb-8">COMMUNITY RULES</SectionLabel>
          <ol className="border-t border-white/10">
            {rules.map((r) => (
              <Rule key={r.n} {...r} />
            ))}
          </ol>
          <div className="mt-14">
            <MagneticButton href="/join">FIND YOUR PEOPLE →</MagneticButton>
          </div>
        </div>
      </section>
    </>
  );
}
