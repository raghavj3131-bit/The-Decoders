"use client";
import { useState } from "react";
import { siteConfig } from "@/config/site";
import { submitAccessRequest, type AccessRequest } from "@/lib/submitAccessRequest";
import MagneticButton from "@/components/ui/MagneticButton";

type Errors = Partial<Record<keyof AccessRequest, string>>;
type Phase = "form" | "decoding" | "done" | "error";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validate(d: AccessRequest): Errors {
  const e: Errors = {};
  const name = d.name.trim();
  if (!name) e.name = "Enter your name.";
  else if (name.length < 2) e.name = "Name must be at least 2 characters.";
  const email = d.email.trim();
  if (!email) e.email = "Enter your email.";
  else if (!EMAIL.test(email)) e.email = "Enter a valid email, like name@example.com.";
  const digits = d.phone.replace(/\D/g, "");
  if (!d.phone.trim()) e.phone = "Enter your phone number.";
  else if (!/^\+?[\d\s-]+$/.test(d.phone.trim()) || digits.length < 10 || digits.length > 15) e.phone = "Enter a valid phone number (10–15 digits).";
  if (!d.classOrExam.trim()) e.classOrExam = "Enter your class or exam.";
  if (!d.city.trim()) e.city = "Enter your city.";
  return e;
}

const FIELDS: { key: keyof AccessRequest; label: string; type: string; max: number; auto: string; placeholder: string }[] = [
  { key: "name", label: "NAME", type: "text", max: 60, auto: "name", placeholder: "Your full name" },
  { key: "email", label: "EMAIL", type: "email", max: 120, auto: "email", placeholder: "name@example.com" },
  { key: "phone", label: "PHONE", type: "tel", max: 20, auto: "tel", placeholder: "+91 98765 43210" },
  { key: "classOrExam", label: "CLASS / EXAM", type: "text", max: 60, auto: "off", placeholder: "e.g. Class 12, JEE, B.Tech 1st year" },
  { key: "city", label: "CITY", type: "text", max: 60, auto: "address-level2", placeholder: "Your city" },
];

export default function JoinForm() {
  const [data, setData] = useState<AccessRequest>({ name: "", email: "", phone: "", classOrExam: "", city: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [phase, setPhase] = useState<Phase>("form");
  const [demo, setDemo] = useState(false);
  const [msg, setMsg] = useState("");

  const onSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const errs = validate(data);
    setErrors(errs);
    if (Object.keys(errs).length) {
      const first = FIELDS.find((f) => errs[f.key]);
      if (first) document.getElementById(`f-${first.key}`)?.focus();
      return;
    }
    setPhase("decoding");
    const res = await submitAccessRequest({
      name: data.name.trim(),
      email: data.email.trim(),
      phone: data.phone.trim(),
      classOrExam: data.classOrExam.trim(),
      city: data.city.trim(),
    });
    if (res.ok) {
      setDemo(res.demo);
      setPhase("done");
    } else {
      setMsg(res.error ?? "Something went wrong.");
      setPhase("error");
    }
  };

  if (phase === "decoding" || phase === "done") {
    const done = phase === "done";
    return (
      <div role="status" aria-live="polite" className="rounded-2xl border border-volt/50 bg-abyss p-8 md:p-12" style={{ boxShadow: "0 0 60px rgba(139,92,246,.25)" }}>
        <p className="font-mono text-xs tracking-[0.3em] text-volt-hot">{done ? "CONNECTED." : "DECODING..."}</p>
        <h2 className="mt-4 font-display text-[clamp(2.4rem,6vw,5rem)] leading-[0.95] text-ink">
          ACCESS REQUEST
          <br />
          RECEIVED
        </h2>
        {done && demo && (
          <p className="mt-6 max-w-md border-l-2 border-signal pl-4 text-sm text-ash">
            <strong className="text-ink">DEMO SUBMISSION.</strong> This site has no backend connected yet, so nothing was stored or sent. Connect one in lib/submitAccessRequest.ts.
          </p>
        )}
        {done && !demo && <p className="mt-6 max-w-md text-sm text-ash">We have your details and will be in touch.</p>}
        {done && siteConfig.links.whatsapp && (
          <div className="mt-8">
            <MagneticButton href={siteConfig.links.whatsapp} variant="primary">
              OPEN WHATSAPP →
            </MagneticButton>
          </div>
        )}
        {!done && <div className="mt-8 h-px w-full overflow-hidden bg-white/10"><div className="h-full w-1/3 animate-pulse bg-volt-hot" /></div>}
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-2xl border border-white/10 bg-abyss/80 p-6 backdrop-blur-sm md:p-10">
      <div className="grid gap-6 md:grid-cols-2">
        {FIELDS.map((f) => (
          <div key={f.key} className={f.key === "name" || f.key === "email" ? "md:col-span-2" : ""}>
            <label htmlFor={`f-${f.key}`} className="mb-2 block font-mono text-[11px] tracking-[0.3em] text-ash">
              {f.label}
            </label>
            <input
              id={`f-${f.key}`}
              name={f.key}
              type={f.type}
              maxLength={f.max}
              autoComplete={f.auto}
              placeholder={f.placeholder}
              value={data[f.key]}
              onChange={(e) => setData((d) => ({ ...d, [f.key]: e.target.value }))}
              aria-invalid={errors[f.key] ? true : undefined}
              aria-describedby={errors[f.key] ? `e-${f.key}` : undefined}
              className={`w-full border-b bg-transparent py-3 text-lg text-ink outline-none transition-colors placeholder:text-ash/50 focus:border-volt-hot ${errors[f.key] ? "border-signal" : "border-white/20"}`}
            />
            {errors[f.key] && (
              <p id={`e-${f.key}`} className="mt-2 text-sm text-signal">
                {errors[f.key]}
              </p>
            )}
          </div>
        ))}
      </div>
      {phase === "error" && (
        <p role="alert" className="mt-6 text-sm text-signal">
          {msg} Try again.
        </p>
      )}
      <div className="mt-10">
        <MagneticButton type="submit" variant="primary" className="w-full sm:w-auto">
          REQUEST ACCESS →
        </MagneticButton>
      </div>
    </form>
  );
}
