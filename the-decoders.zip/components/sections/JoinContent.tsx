import JoinForm from "./JoinForm";
import FaqAccordion from "./FaqAccordion";
import SectionLabel from "@/components/ui/SectionLabel";

export default function JoinContent() {
  return (
    <>
      <section className="relative pb-24 md:pb-32">
        <div className="mx-auto grid max-w-[1500px] gap-12 px-5 md:grid-cols-[1fr_1.4fr] md:px-12">
          <div>
            <SectionLabel className="mb-4">ACCESS REQUEST</SectionLabel>
            <p className="max-w-sm text-lg text-ink/85">
              Tell us who you are and what you want to decode. We use these details to invite you into the community.
            </p>
          </div>
          <JoinForm />
        </div>
      </section>
      <section className="border-t border-white/10 bg-night py-24 md:py-32">
        <div className="mx-auto max-w-[1100px] px-5 md:px-12">
          <SectionLabel className="mb-8">FAQ</SectionLabel>
          <FaqAccordion />
        </div>
      </section>
    </>
  );
}
