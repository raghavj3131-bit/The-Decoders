"use client";
import { useState } from "react";
import { faqs } from "@/data/faqs";

export default function FaqAccordion() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <ul className="border-t border-white/10">
      {faqs.map((f, i) => {
        const isOpen = open === i;
        return (
          <li key={f.q} className="border-b border-white/10">
            <h3>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`faq-${i}`}
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-baseline gap-6 py-6 text-left"
              >
                <span className="font-mono text-xs tracking-[0.3em] text-volt-hot">{String(i + 1).padStart(2, "0")}</span>
                <span className="flex-1 font-display text-2xl text-ink md:text-4xl">{f.q}</span>
                <span aria-hidden="true" className={`font-mono text-2xl text-volt-hot transition-transform duration-500 ${isOpen ? "rotate-45" : ""}`}>
                  +
                </span>
              </button>
            </h3>
            <div id={`faq-${i}`} role="region" className={`faq-panel ${isOpen ? "open" : ""}`}>
              <div>
                <p className="max-w-2xl pb-6 pl-12 text-ash md:pl-14">{f.a}</p>
              </div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
