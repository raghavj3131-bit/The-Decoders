"use client";
import { programs, type Program } from "@/data/programs";
import ProgramVisual from "@/components/ui/ProgramVisual";
import MagneticButton from "@/components/ui/MagneticButton";
import TextReveal from "@/components/animations/TextReveal";
import Halftone from "@/components/effects/Halftone";
import ParallaxLayer from "@/components/animations/ParallaxLayer";

function Block({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h4 className="mb-3 font-mono text-[11px] tracking-[0.3em] text-volt-hot">{title}</h4>
      <ul className="space-y-2 text-sm text-ink/80">
        {items.map((i) => (
          <li key={i} className="flex gap-3">
            <span className="mt-2 h-1 w-3 shrink-0 bg-volt" aria-hidden="true" />
            {i}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Chapter({ p, i }: { p: Program; i: number }) {
  const flip = i % 2 === 1;
  return (
    <section id={p.id} className="relative overflow-hidden border-t border-white/10 py-24 md:py-36">
      <Halftone opacity={0.1} x={flip ? "20%" : "80%"} y="30%" size={16} />
      <ParallaxLayer speed={0.4} className="pointer-events-none absolute inset-0">
        <div className={`absolute top-10 h-[50vmin] w-[50vmin] rounded-full bg-volt-deep/15 blur-[110px] ${flip ? "left-0" : "right-0"}`} />
      </ParallaxLayer>
      <div className="relative mx-auto max-w-[1500px] px-5 md:px-12">
        <div className={`flex flex-col gap-10 md:items-end md:justify-between ${flip ? "md:flex-row-reverse" : "md:flex-row"}`}>
          <div>
            <p className="font-mono text-xs tracking-[0.3em] text-ash">CHAPTER {p.number}</p>
            <TextReveal as="h2" by="char" stagger={0.03} text={p.title} className="mt-3 font-display text-[clamp(3rem,10.5vw,10rem)] leading-[0.88] text-ink" />
            <p className="mt-4 font-mono text-xs tracking-[0.25em] text-volt-hot">{p.tagline.toUpperCase()}</p>
          </div>
          <ProgramVisual id={p.id} className="h-40 w-40 md:h-64 md:w-64" />
        </div>

        <div className="mt-14 grid gap-12 md:grid-cols-[1.2fr_2fr]">
          <div>
            <h3 className="mb-3 font-mono text-[11px] tracking-[0.3em] text-volt-hot">WHAT IT IS</h3>
            <p className="max-w-md text-lg leading-relaxed text-ink/85">{p.what}</p>
            <div className="mt-8">
              <MagneticButton href="/join">JOIN THIS TRACK →</MagneticButton>
            </div>
          </div>
          <div className="grid gap-10 sm:grid-cols-2">
            <Block title="WHAT YOU LEARN" items={p.learn} />
            <Block title="PROJECTS" items={p.projects} />
            <Block title="SKILLS" items={p.skills} />
            <Block title="OPPORTUNITIES" items={p.opportunities} />
          </div>
        </div>
      </div>
    </section>
  );
}

export default function ProgramChapters() {
  return (
    <>
      {programs.map((p, i) => (
        <Chapter key={p.id} p={p} i={i} />
      ))}
    </>
  );
}
