/** Deterministic generative placeholder (no stock photos, no fake faces). */
const hash = (s: string) => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return Math.abs(h);
};

export default function PlaceholderArt({ seed, className = "", label }: { seed: string; className?: string; label?: string }) {
  const h = hash(seed);
  const a = h % 100;
  const b = (h >> 3) % 100;
  const c = (h >> 6) % 100;
  const rot = h % 360;
  return (
    <div
      className={`relative overflow-hidden bg-abyss ${className}`}
      style={{
        backgroundImage: `radial-gradient(circle at ${a}% ${b}%, rgba(168,85,247,.55), transparent 45%), radial-gradient(circle at ${c}% ${100 - a}%, rgba(124,58,237,.4), transparent 50%), conic-gradient(from ${rot}deg at 50% 60%, #0D0915, #050507, #150C2B, #0D0915)`,
      }}
      role="img"
      aria-label={label ?? "Placeholder image"}
    >
      <div
        className="absolute inset-0 opacity-40"
        style={{ backgroundImage: "radial-gradient(circle, rgba(245,245,245,.5) 1px, transparent 1.6px)", backgroundSize: "12px 12px", WebkitMaskImage: `radial-gradient(circle at ${b}% ${c}%, #000, transparent 65%)`, maskImage: `radial-gradient(circle at ${b}% ${c}%, #000, transparent 65%)` }}
      />
      {label && (
        <span className="absolute bottom-3 left-3 font-mono text-[10px] tracking-[0.3em] text-ink/70">{label}</span>
      )}
    </div>
  );
}
