"use client";
import { useRef } from "react";
import { useFinePointer, useReducedMotion } from "@/hooks/useMediaFlags";

export default function TiltCard({
  children,
  className = "",
  innerClassName = "",
  max = 9,
}: {
  children: React.ReactNode;
  className?: string;
  innerClassName?: string;
  max?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const fine = useFinePointer();
  const reduced = useReducedMotion();
  const enabled = fine && !reduced;

  const move = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!enabled || !el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.setProperty("--rx", `${(0.5 - py) * max}deg`);
    el.style.setProperty("--ry", `${(px - 0.5) * max}deg`);
    el.style.setProperty("--gx", `${px * 100}%`);
    el.style.setProperty("--gy", `${py * 100}%`);
  };
  const leave = () => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };

  return (
    <div
      ref={ref}
      data-cursor="card"
      className={`tilt ${enabled ? "tilt-on" : ""} ${className}`}
      onPointerMove={move}
      onPointerLeave={leave}
    >
      <div className={`tilt-inner ${innerClassName}`}>
        {children}
        <span className="tilt-glare" aria-hidden="true" />
        <span className="tilt-border" aria-hidden="true" />
      </div>
    </div>
  );
}
