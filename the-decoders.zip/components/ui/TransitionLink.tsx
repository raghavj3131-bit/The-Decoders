"use client";
import Link from "next/link";
import type { ComponentProps, MouseEvent } from "react";
import { useShutter } from "@/components/providers/ShutterTransitionProvider";
import { scrollState } from "@/lib/scrollState";

type Props = Omit<ComponentProps<typeof Link>, "href"> & {
  href: string;
  /** Primary CTA: radial splash + shake + flash before the shutter. */
  cta?: boolean;
  onNavigate?: () => void;
};

export default function TransitionLink({ href, cta = false, onNavigate, onClick, children, ...rest }: Props) {
  const { navigate } = useShutter();

  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    let x = e.clientX;
    let y = e.clientY;
    if (e.detail === 0) {
      const r = e.currentTarget.getBoundingClientRect();
      x = r.left + r.width / 2;
      y = r.top + r.height / 2;
    }
    navigate(href, { cta, x, y, onStart: onNavigate });
  };

  return (
    <Link href={href} onClick={handle} data-cta={cta ? "" : undefined} {...rest}>
      {children}
    </Link>
  );
}

/** In-page anchor scroll that cooperates with Lenis. */
export function scrollToHash(hash: string) {
  const el = document.querySelector(hash);
  if (!el) return;
  const l = scrollState.lenis;
  if (l) l.scrollTo(el as HTMLElement, { offset: 0 });
  else el.scrollIntoView({ behavior: "auto" });
}
