"use client";
import { useEffect } from "react";
import { useInView } from "@/hooks/useInView";
import { loadAnime } from "@/lib/loadAnime";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

/** Decorative stroke that draws itself with anime.js when scrolled into view. */
export default function DrawStroke({
  d = "M0 10 H190 L200 2",
  viewBox = "0 0 200 20",
  className = "h-4 w-40 text-volt-hot",
}: {
  d?: string;
  viewBox?: string;
  className?: string;
}) {
  const [ref, seen] = useInView<SVGSVGElement>(0.5);

  useEffect(() => {
    if (!seen || prefersReducedMotion() || !ref.current) return;
    let anim: { pause: () => void } | undefined;
    let stop = false;
    loadAnime().then((anime) => {
      if (stop || !ref.current) return;
      anim = anime({
        targets: ref.current.querySelectorAll("path"),
        strokeDashoffset: [anime.setDashoffset, 0],
        duration: 1200,
        delay: anime.stagger(80),
        easing: "easeOutQuart",
      });
    });
    return () => {
      stop = true;
      anim?.pause();
    };
  }, [seen, ref]);

  return (
    <svg ref={ref} viewBox={viewBox} fill="none" stroke="currentColor" strokeWidth={1.5} aria-hidden="true" className={className}>
      <path d={d} />
    </svg>
  );
}
