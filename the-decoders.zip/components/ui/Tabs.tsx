"use client";
import { useId } from "react";
import { motion } from "framer-motion";

export default function Tabs<T extends string>({
  tabs,
  value,
  onChange,
  label,
  className = "",
}: {
  tabs: readonly T[];
  value: T;
  onChange: (v: T) => void;
  label: string;
  className?: string;
}) {
  const id = useId();
  return (
    <div role="tablist" aria-label={label} className={`flex flex-wrap gap-x-2 gap-y-2 ${className}`}>
      {tabs.map((t) => {
        const active = t === value;
        return (
          <button
            key={t}
            role="tab"
            type="button"
            id={`${id}-${t}`}
            aria-selected={active}
            onClick={() => onChange(t)}
            className={`relative px-4 py-3 font-mono text-[11px] uppercase tracking-[0.25em] transition-colors ${active ? "text-ink" : "text-ash hover:text-ink"}`}
          >
            {active && (
              <motion.span
                layoutId={`${id}-pill`}
                className="absolute inset-0 -z-10 border border-volt bg-volt/15"
                style={{ boxShadow: "0 0 24px rgba(139,92,246,.35)" }}
                transition={{ type: "spring", stiffness: 420, damping: 36 }}
              />
            )}
            {t}
          </button>
        );
      })}
    </div>
  );
}
