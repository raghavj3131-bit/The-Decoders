"use client";
import { useEffect } from "react";
import { useInView } from "@/hooks/useInView";
import { loadAnime } from "@/lib/loadAnime";
import { prefersReducedMotion } from "@/hooks/useMediaFlags";

const VISUALS: Record<string, string[]> = {
  ai: [
    "M30 100 L100 40 L170 100 L100 160 Z",
    "M100 40 L100 160 M30 100 L170 100",
    "M95 100a5 5 0 1 0 10 0a5 5 0 1 0 -10 0",
  ],
  robotics: ["M100 30 L160 65 L160 135 L100 170 L40 135 L40 65 Z", "M100 70 L100 130 M70 100 L130 100", "M88 100a12 12 0 1 0 24 0a12 12 0 1 0 -24 0"],
  coding: ["M70 60 L30 100 L70 140", "M130 60 L170 100 L130 140", "M115 50 L85 150"],
  design: ["M30 150 C60 20 140 20 170 150", "M30 150 L60 20 M170 150 L140 20", "M52 12h16v16h-16z M132 12h16v16h-16z"],
  entrepreneurship: ["M30 160 L80 160 L80 120 L120 120 L120 80 L160 80 L160 40", "M140 40 L160 40 L160 60", "M30 175 H170"],
  cybersecurity: ["M100 25 L165 50 L165 105 C165 140 135 165 100 178 C65 165 35 140 35 105 L35 50 Z", "M75 100 L95 120 L130 80"],
  media: ["M100 30a70 70 0 1 0 0.01 0Z", "M85 70 L135 100 L85 130 Z"],
  research: ["M85 40a45 45 0 1 0 0.01 0Z", "M120 120 L170 170", "M65 85 L105 85 M65 105 L95 105"],
};

export default function ProgramVisual({ id, className = "" }: { id: string; className?: string }) {
  const [ref, seen] = useInView<SVGSVGElement>(0.3);
  const paths = VISUALS[id] ?? VISUALS.ai;

  useEffect(() => {
    if (!seen || prefersReducedMotion() || !ref.current) return;
    let anim: { pause: () => void } | undefined;
    let stop = false;
    loadAnime().then((anime) => {
      if (stop || !ref.current) return;
      anim = anime({
        targets: ref.current.querySelectorAll("path"),
        strokeDashoffset: [anime.setDashoffset, 0],
        duration: 1400,
        delay: anime.stagger(140),
        easing: "easeOutQuart",
      });
    });
    return () => {
      stop = true;
      anim?.pause();
    };
  }, [seen, ref]);

  return (
    <svg
      ref={ref}
      viewBox="0 0 200 200"
      fill="none"
      stroke="#A855F7"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
      style={{ filter: "drop-shadow(0 0 10px rgba(168,85,247,.55))" }}
    >
      {paths.map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}
