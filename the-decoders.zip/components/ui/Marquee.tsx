"use client";
import { useEffect, useRef } from "react";
import { scrollState } from "@/lib/scrollState";
import { useReducedMotion } from "@/hooks/useMediaFlags";

export default function Marquee({
  items,
  baseSpeed = 70,
  className = "",
}: {
  items: readonly string[];
  baseSpeed?: number;
  className?: string;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const el = track.current;
    const host = wrap.current;
    if (!el || !host || reduced) return;
    let x = 0;
    let last = performance.now();
    let raf = 0;
    let visible = true;
    let v = 0;

    const loop = (now: number) => {
      if (!visible) {
        raf = 0;
        return;
      }
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const boost = 1 + Math.min(8, v * 0.12); // faster when scrolling fast
      v *= 0.92;
      const half = el.scrollWidth / 2;
      x -= baseSpeed * boost * dt;
      if (-x >= half) x += half;
      el.style.transform = `translate3d(${x}px,0,0)`;
      raf = requestAnimationFrame(loop);
    };

    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible && !raf) {
        last = performance.now();
        raf = requestAnimationFrame(loop);
      }
    });
    io.observe(host);
    const unsub = scrollState.subscribe((vel) => {
      v = Math.max(v, Math.abs(vel));
    });
    raf = requestAnimationFrame(loop);

    return () => {
      io.disconnect();
      unsub();
      cancelAnimationFrame(raf);
    };
  }, [baseSpeed, reduced]);

  const row = (hidden: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {items.map((t, i) => (
        <li key={`${t}${i}`} className="flex items-center">
          <span className={`px-6 font-display text-[clamp(3rem,9vw,8rem)] leading-none ${i % 2 ? "text-outline-white" : "text-ink"}`}>
            {t}
          </span>
          <span className="text-volt-hot" aria-hidden="true">✦</span>
        </li>
      ))}
    </ul>
  );

  return (
    <div ref={wrap} className={`overflow-hidden whitespace-nowrap ${className}`}>
      <div ref={track} className="flex w-max will-change-transform">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}
