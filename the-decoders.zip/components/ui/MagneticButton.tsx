"use client";
import { useRef } from "react";
import TransitionLink, { scrollToHash } from "./TransitionLink";
import { useFinePointer, useReducedMotion } from "@/hooks/useMediaFlags";

type Props = {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "ghost";
  cta?: boolean;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  "aria-label"?: string;
};

export default function MagneticButton({
  children,
  href,
  onClick,
  variant = "primary",
  cta,
  className = "",
  type = "button",
  disabled,
  ...aria
}: Props) {
  const wrap = useRef<HTMLSpanElement>(null);
  const fine = useFinePointer();
  const reduced = useReducedMotion();
  const enabled = fine && !reduced && !disabled;

  const move = (e: React.PointerEvent<HTMLSpanElement>) => {
    if (!enabled || !wrap.current) return;
    const r = wrap.current.getBoundingClientRect();
    const dx = Math.max(-10, Math.min(10, (e.clientX - (r.left + r.width / 2)) * 0.22));
    const dy = Math.max(-8, Math.min(8, (e.clientY - (r.top + r.height / 2)) * 0.22));
    wrap.current.style.transition = "transform .1s linear";
    wrap.current.style.transform = `translate3d(${dx}px,${dy}px,0)`;
  };
  const leave = () => {
    if (!wrap.current) return;
    wrap.current.style.transition = "transform .6s cubic-bezier(.16,1,.3,1)";
    wrap.current.style.transform = "translate3d(0,0,0)";
  };

  const base =
    "relative inline-flex min-h-[52px] items-center justify-center gap-3 px-8 py-4 font-mono text-xs font-medium uppercase tracking-[0.22em] transition-[background,box-shadow,border-color] duration-300 disabled:opacity-50";
  const look =
    variant === "primary"
      ? "border border-volt bg-volt/15 text-ink hover:bg-volt hover:shadow-[0_0_46px_rgba(139,92,246,.65)]"
      : "border border-white/20 text-ink hover:border-volt-hot hover:shadow-[0_0_30px_rgba(139,92,246,.35)]";
  const cls = `${base} ${look} ${className}`;

  let inner: React.ReactNode;
  if (href && href.startsWith("/")) {
    inner = (
      <TransitionLink href={href} cta={cta ?? variant === "primary"} className={cls} {...aria}>
        {children}
      </TransitionLink>
    );
  } else if (href && href.startsWith("#")) {
    inner = (
      <a
        href={href}
        className={cls}
        onClick={(e) => {
          e.preventDefault();
          scrollToHash(href);
        }}
        {...aria}
      >
        {children}
      </a>
    );
  } else if (href) {
    inner = (
      <a href={href} target="_blank" rel="noopener noreferrer" className={cls} {...aria}>
        {children}
      </a>
    );
  } else {
    inner = (
      <button type={type} onClick={onClick} disabled={disabled} className={cls} {...aria}>
        {children}
      </button>
    );
  }

  return (
    <span ref={wrap} className="inline-block" onPointerMove={move} onPointerLeave={leave}>
      {inner}
    </span>
  );
}
