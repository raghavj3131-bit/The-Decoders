export default function SectionLabel({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <p className={`font-mono text-[11px] uppercase tracking-[0.3em] text-ash ${className}`}>{children}</p>
  );
}
