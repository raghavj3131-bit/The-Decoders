"use client";
import { useCallback, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import TransitionLink from "@/components/ui/TransitionLink";
import FullscreenMenu from "./FullscreenMenu";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const close = useCallback(() => setOpen(false), []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <>
      <header className="pointer-events-none fixed inset-x-0 top-0 z-[8100] flex items-start justify-between p-5 md:p-8" data-nav>
        <TransitionLink
          href="/"
          aria-label="The Decoders — home"
          onNavigate={close}
          className="pointer-events-auto flex items-center gap-3"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.svg" alt="" className="h-10 w-auto md:h-12" />
          <span className="hidden font-mono text-[10px] leading-4 tracking-[0.25em] text-ash sm:block">
            THE DECODERS
            <br />
            <span className="text-volt-hot">STATUS: ONLINE</span>
          </span>
        </TransitionLink>

        <button
          type="button"
          aria-expanded={open}
          aria-controls="fullscreen-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((o) => !o)}
          className="pointer-events-auto relative grid h-14 w-14 place-items-center rounded-full border border-white/25 bg-void/60 backdrop-blur-md transition-[border-color,box-shadow] hover:border-volt-hot hover:shadow-[0_0_30px_rgba(139,92,246,.5)]"
        >
          <span className="relative block h-3 w-6" aria-hidden="true">
            <span className={`absolute left-0 h-px w-6 bg-ink transition-all duration-500 ${open ? "top-1/2 rotate-45" : "top-0"}`} />
            <span className={`absolute left-0 h-px w-6 bg-ink transition-all duration-500 ${open ? "top-1/2 -rotate-45" : "bottom-0"}`} />
          </span>
        </button>
      </header>
      <FullscreenMenu open={open} onClose={close} />
    </>
  );
}
