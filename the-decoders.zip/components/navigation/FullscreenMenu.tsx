"use client";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { siteConfig } from "@/config/site";
import { useShutter } from "@/components/providers/ShutterTransitionProvider";
import { scrollState } from "@/lib/scrollState";

export default function FullscreenMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { navigate } = useShutter();
  const pathname = usePathname();
  const first = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const l = scrollState.lenis;
    if (open) {
      l?.stop();
      document.body.style.overflow = "hidden";
      first.current?.focus({ preventScroll: true });
    } else {
      l?.start();
      document.body.style.overflow = "";
    }
    return () => {
      l?.start();
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const socials = Object.entries(siteConfig.links).filter(([, v]) => v);

  return (
    <div id="fullscreen-menu" className={`menu ${open ? "open" : ""}`} role="dialog" aria-modal="true" aria-label="Site menu" aria-hidden={!open}>
      <div className="mx-auto flex min-h-full max-w-[1500px] flex-col justify-center px-6 pb-10 pt-28 md:px-14">
        <nav aria-label="Primary">
          <ul className="grid gap-x-16 md:grid-cols-2">
            {siteConfig.nav.map((item, i) => {
              const current = pathname === item.href;
              return (
                <li key={item.href} className="menu-item border-b border-white/10" style={{ ["--i" as string]: i }}>
                  <span className="menu-in">
                    <Link
                      href={item.href}
                      ref={i === 0 ? first : undefined}
                      aria-current={current ? "page" : undefined}
                      tabIndex={open ? 0 : -1}
                      onClick={(e) => {
                        e.preventDefault();
                        onClose();
                        navigate(item.href);
                      }}
                      className={`group flex items-baseline gap-4 py-2 font-display text-[clamp(2rem,6.2vw,4.8rem)] leading-[1.05] transition-colors md:py-3 ${current ? "text-volt-hot" : "text-ink hover:text-volt-hot"}`}
                    >
                      <span className="font-mono text-xs tracking-[0.3em] text-ash group-hover:text-volt-hot">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="transition-transform duration-500 group-hover:translate-x-3">{item.label}</span>
                    </Link>
                  </span>
                </li>
              );
            })}
          </ul>
        </nav>
        <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-2 font-mono text-[11px] uppercase tracking-[0.25em] text-ash">
          <span>SYSTEM 01 // THE DECODERS</span>
          {socials.map(([k, v]) => (
            <a key={k} href={v} target="_blank" rel="noopener noreferrer" tabIndex={open ? 0 : -1} className="hover:text-volt-hot">
              {k}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
