import type { CSSProperties } from "react";

export default function Halftone({
  className = "",
  opacity = 0.18,
  size = 14,
  x = "70%",
  y = "40%",
}: {
  className?: string;
  opacity?: number;
  size?: number;
  x?: string;
  y?: string;
}) {
  const style = { opacity, "--ht": `${size}px`, "--hx": x, "--hy": y } as CSSProperties;
  return <div aria-hidden="true" className={`halftone ${className}`} style={style} />;
}
