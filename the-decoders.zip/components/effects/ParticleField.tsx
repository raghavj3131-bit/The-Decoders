"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { PointMaterial } from "@react-three/drei";
import * as THREE from "three";

type Mouse = { x: number; y: number };

function Stars({ count, mouse }: { count: number; mouse: React.MutableRefObject<Mouse> }) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const a = new Float32Array(count * 3);
    let s = 1337;
    const rnd = () => {
      s = (s * 16807) % 2147483647;
      return s / 2147483647;
    };
    for (let i = 0; i < count; i++) {
      a[i * 3] = (rnd() - 0.5) * 14;
      a[i * 3 + 1] = (rnd() - 0.5) * 8;
      a[i * 3 + 2] = (rnd() - 0.5) * 8;
    }
    return a;
  }, [count]);

  useFrame((_, dt) => {
    const p = ref.current;
    if (!p) return;
    p.rotation.y += dt * 0.02;
    p.rotation.x = THREE.MathUtils.lerp(p.rotation.x, mouse.current.y * 0.12, 0.04);
    p.position.x = THREE.MathUtils.lerp(p.position.x, mouse.current.x * 0.3, 0.04);
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <PointMaterial transparent color="#A855F7" size={0.035} sizeAttenuation depthWrite={false} opacity={0.9} />
    </points>
  );
}

export default function ParticleField({ count = 600 }: { count?: number }) {
  const wrap = useRef<HTMLDivElement>(null);
  const mouse = useRef<Mouse>({ x: 0, y: 0 });
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { threshold: 0 });
    io.observe(el);
    const move = (e: PointerEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = -((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      io.disconnect();
      window.removeEventListener("pointermove", move);
    };
  }, []);

  return (
    <div ref={wrap} aria-hidden="true" className="pointer-events-none absolute inset-0">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 60 }}
        dpr={[1, 1.5]}
        gl={{ antialias: false, powerPreference: "low-power", alpha: true }}
        frameloop={visible ? "always" : "never"}
      >
        <Stars count={count} mouse={mouse} />
      </Canvas>
    </div>
  );
}
