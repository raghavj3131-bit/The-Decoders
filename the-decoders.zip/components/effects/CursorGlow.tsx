"use client";
import { useEffect, useRef, useState } from "react";
import { useFinePointer, useReducedMotion } from "@/hooks/useMediaFlags";

export default function CursorGlow() {
  const fine = useFinePointer();
  const reduced = useReducedMotion();
  const dot = useRef<HTMLDivElement>(null);
  const glow = useRef<HTMLDivElement>(null);
  const [mode, setMode] = useState("idle");
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    if (!fine) return;
    document.documentElement.classList.add("has-cursor");
    let x = -200;
    let y = -200;
    let gx = x;
    let gy = y;
    let raf = 0;

    const move = (e: PointerEvent) => {
      x = e.clientX;
      y = e.clientY;
      if (dot.current) dot.current.style.transform = `translate3d(${x}px,${y}px,0)`;
      setHidden(false);
      const t = (e.target as Element | null)?.closest?.("[data-cursor],a,button,input,textarea,select,summary");
      let kind = "idle";
      if (t) {
        const tag = t.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") kind = "text";
        else kind = t.getAttribute("data-cursor") || (t.closest("nav,header,[data-nav]") ? "nav" : "button");
      }
      setMode((p) => (p === kind ? p : kind));
    };
    const leave = () => setHidden(true);

    const loop = () => {
      gx += (x - gx) * 0.14;
      gy += (y - gy) * 0.14;
      if (glow.current) glow.current.style.transform = `translate3d(${gx}px,${gy}px,0)`;
      raf = requestAnimationFrame(loop);
    };
    if (!reduced) raf = requestAnimationFrame(loop);

    window.addEventListener("pointermove", move, { passive: true });
    document.documentElement.addEventListener("pointerleave", leave);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", move);
      document.documentElement.removeEventListener("pointerleave", leave);
      document.documentElement.classList.remove("has-cursor");
    };
  }, [fine, reduced]);

  if (!fine) return null;

  return (
    <div aria-hidden="true">
      <div ref={glow} className="cursor-wrap" style={{ zIndex: 9790 }}>
        <div className="cursor-glow" data-mode={mode} data-hidden={hidden} />
      </div>
      <div ref={dot} className="cursor-wrap">
        <div className="cursor-dot" data-mode={mode} data-hidden={hidden} />
      </div>
    </div>
  );
}
