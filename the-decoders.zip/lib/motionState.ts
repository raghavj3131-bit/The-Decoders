import { useSyncExternalStore } from "react";

let ready = false;
const subs = new Set<() => void>();

export const motionState = {
  get ready() {
    return ready;
  },
  setReady(v: boolean) {
    if (ready === v) return;
    ready = v;
    subs.forEach((f) => f());
  },
  subscribe(f: () => void) {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  },
};

/** true once the loader / shutter has revealed the page. Hero animations wait on this. */
export function useReady() {
  return useSyncExternalStore(
    motionState.subscribe,
    () => ready,
    () => false
  );
}
