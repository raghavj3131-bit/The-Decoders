import { siteConfig } from "@/config/site";

export type AccessRequest = {
  name: string;
  email: string;
  phone: string;
  classOrExam: string;
  city: string;
};

export type SubmitResult = { ok: boolean; demo: boolean; error?: string };

/**
 * BACKEND INTEGRATION POINT.
 * - No endpoint configured  -> DEMO mode: nothing is stored, and the UI says so.
 * - NEXT_PUBLIC_JOIN_ENDPOINT set -> POSTs JSON; success is only reported if the server answers 2xx.
 */
export async function submitAccessRequest(data: AccessRequest): Promise<SubmitResult> {
  const endpoint = siteConfig.external.joinEndpoint;
  if (!endpoint) {
    await new Promise((r) => setTimeout(r, 1400));
    return { ok: true, demo: true };
  }
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) return { ok: false, demo: false, error: `Server responded ${res.status}` };
    return { ok: true, demo: false };
  } catch {
    return { ok: false, demo: false, error: "Network error. Try again." };
  }
}
