import type Lenis from "lenis";

type Listener = (velocity: number) => void;
const listeners = new Set<Listener>();

export const scrollState = {
  lenis: null as Lenis | null,
  velocity: 0,
  subscribe(fn: Listener) {
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  },
  emit(v: number) {
    scrollState.velocity = v;
    listeners.forEach((f) => f(v));
  },
};
