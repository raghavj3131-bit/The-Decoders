import type animeNs from "animejs";

export type AnimeFn = typeof animeNs;

export async function loadAnime(): Promise<AnimeFn> {
  const mod = (await import("animejs")) as unknown as { default?: AnimeFn };
  return mod.default ?? (mod as unknown as AnimeFn);
}
