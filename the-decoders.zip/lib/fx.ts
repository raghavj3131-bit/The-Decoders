/** Tiny event bus for global effects. Listeners live in ClickSplash / ImpactFlash. */
const fire = (name: string, detail?: unknown) => {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(name, { detail }));
};

export const fx = {
  splash(x: number, y: number, kind: "normal" | "cta" = "normal") {
    fire("decoders:splash", { x, y, kind });
  },
  flash() {
    fire("decoders:flash");
  },
  shake() {
    fire("decoders:shake");
  },
};
